using System ;
namespace sample
{
	class Class1
	{
		static void Main ( string[ ] args )
		{
			string s1 = "kicit" ;
			string s2 = "Nagpur" ;
			Console.WriteLine ( "Char at 3rd position: " + s1 [ 2 ] ) ;

			string s3 = string.Concat ( s1, s2 ) ;
			Console.WriteLine ( s3 ) ;
			Console.WriteLine ( "Length of s3: " + s3.Length ) ;

			s3 = s3.Replace ( 'p', 'P' ) ;
			Console.WriteLine ( s3 ) ;

			s3 = string.Copy ( s2 ) ;
			Console.WriteLine ( s3 ) ;

			int c = s2.CompareTo ( s3 ) ;
			if ( c < 0 )
				Console.WriteLine ( "s2 is less than s3" ) ;
			if ( c == 0 )
				Console.WriteLine ( "s2 is equal to s3" ) ;
			if ( c > 0 )
				Console.WriteLine ( "s2 is greater than s3" ) ;

			if ( s1 == s3 ) 
				Console.WriteLine ( "s1 is equal to s3" ) ;
			else
				Console.WriteLine ( "s1 is not equal to s3" ) ;

			s3 = s1.ToUpper( ) ;
			Console.WriteLine ( s3 ) ;

			s3 = s2.Insert ( 6, "Mumbai" ) ;
			Console.WriteLine ( s3 ) ;

			s3 = s2.Remove ( 0, 1 ) ;
			Console.WriteLine ( s3 ) ;

			int fin = s1.IndexOf ( 'i' ) ;
			Console.WriteLine ( "First index of i in s1: " +  fin ) ;

			int lin = s1.LastIndexOf ( 'i' ) ;
			Console.WriteLine ( "Last index of i in s1: " + lin ) ;

			string sub = s1.Substring ( fin, lin ) ;
			Console.WriteLine ( "Substring: " + sub ) ;

			int i = 10 ;
			float  f = 9.8f ;
			s3 = string.Format ( "Value of i : {0} \nValue of f : {1}", i, f ) ;
			Console.WriteLine ( s3 ) ;
		}
	}
}
