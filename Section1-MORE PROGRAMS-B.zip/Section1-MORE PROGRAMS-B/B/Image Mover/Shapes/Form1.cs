using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Shapes
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(376, 309);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
				Graphics g = e.Graphics ;

				Pen mypen = new Pen( Color.Red, 5 ) ;
				SolidBrush mybrush = new SolidBrush ( Color.Blue ) ;

				g.DrawLine( mypen, 20, 30, 200, 60 ) ;

				g.FillRectangle( mybrush, 20, 70, 150, 100 );
				g.DrawRectangle( mypen, 20, 70, 150, 100 );

				g.FillEllipse( mybrush, 20, 200, 150, 100);
				g.DrawEllipse( mypen, 20, 200, 150, 100);

				mybrush.Color = Color.FromArgb(0,255,0) ;

				g.FillPie ( mybrush, 210, 40, 100, 100, 0, 140 ) ;
				g.DrawPie ( mypen , 210, 40, 100, 100, 90, 140 ) ; 
				mybrush.Color = Color.Yellow ;

				Point[] p = {new Point(365,270), new Point(300,265),
								new Point( 240,255),new Point( 245,200),new Point( 340,190) } ;
				g.FillPolygon (mybrush, p ) ; 
				g.DrawPolygon( mypen , p ) ;

		}
	}
}
