// AtlServer.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{A60B3C6C-FA0B-4A52-B025-5C1C48F10625}", 
		 name = "AtlServer", 
		 helpstring = "AtlServer 1.0 Type Library",
		 resource_name = "IDR_ATLSERVER") ];
