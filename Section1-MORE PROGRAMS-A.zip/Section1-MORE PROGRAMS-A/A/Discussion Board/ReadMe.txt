Discussion board is an internet based application where the user can post queries for the topics provided and can post his/her answers for the queries that have been listed in the discussion board.

This application provides the following features:

When the user runs this application, a list of different topics get displayed on the web page.

When the user clicks on a topic, a new page gets displayed wherein the user can find queries posted by different people.

A hyperlink is provided to post the queries. If the user clicks on the hyperlink a new page gets displayed where the user can provide his name, query or answer of the query. 

On clicking the 'Submit' button the query gets added. The user is also provided with an option to reply to the query.