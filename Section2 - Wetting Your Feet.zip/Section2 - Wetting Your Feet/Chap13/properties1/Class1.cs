using System ;
namespace properties
{
	public class sample
	{
		int  length ;

		public int Length
		{
			get
			{
				return length ;
			}
			set
			{
				length = value ;
			}
		}
	}

	class Class1
	{
		static void Main ( string[ ] args )
		{
			sample  m = new sample( ) ;

			m.Length = 10 ;
			int len = m.Length ;
			Console.WriteLine ( "Length: " +  len ) ;
			}
	}
}
