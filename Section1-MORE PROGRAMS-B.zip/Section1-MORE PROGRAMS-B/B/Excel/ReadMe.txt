excelclient

In the 'excelclient' application, we have used an ActiveX control to invoke an Excel worksheet. The data in the excel worksheet is fetched from a Microsoft Access database. On executing this program, a window gets displayed containing a button.

Clicking on this button would show an excel worksheet filled with data extracted from the database.

