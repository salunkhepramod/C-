// mcppprog.h
# using "System.dll"
# include "stdafx.h"
using namespace System;
namespace mcppprog
{
	public __gc class mymcppclass
	{
	public:
		void ()
		{
			Console::WriteLine ( "In func1 of Managaed C++ class" );
		}
		virtual void func2()
		{
			Console::WriteLine ( "In func2 of Managaed C++ class" );
		}
	};
}
