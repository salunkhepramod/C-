using System ;
namespace Virtual
{
	class shapes
	{
		public virtual void draw( )
		{
			Console.WriteLine ( "Shapes" ) ;
		}
	}

	class rect : shapes
	{
		public override void draw ( )
		{
			Console.WriteLine ( "Rectangle") ;
		}
	}

	class circle : shapes
	{
		public override void draw ( )
		{
			Console.WriteLine ( "Circle" ) ;
		}
	}

	class Class1
	{
		static void Main (string[ ] args )
		{
			shapes[ ] p = { 
							  new circle( ),
							  new rect( ),
							  new circle( ),
							  new rect( ),
							  new circle( ),
			} ;

			for ( int i = 0 ; i < p.Length ; i++ )
					 p[i].draw( ) ;
		}
	}
}
