The 'dictionary' is a console application that demonstrates the use of a collection class 'SortedList'. On executing this program a menu would popup with following options

 (1) Search a meaning for the word
 (2) Search a word for the meaning
 (3) Add a word and meaning
 (4) Add a meaning
 (5) Delete a word and meaning
 (6) See words and meanings for a particular letter
 (7) Exit

Option 1 allows the user to search a meaning for a word entered. 

Option 2 accepts a meaning from the user and returns the word. 

Option 3 allows the user to add a pair of word and its meaning to the dictionary. 

Option 4 allows the user to add a meaning to an existing word. 

Option 5 deletes a word-meaning pair from the dictionary. 

Option 6 displays all the words and meanings for a particular letter specified by the user. 
Option 7 terminates the program.