using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ServiceClient.localhost ;

namespace ServiceClient
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox dollar;
		protected System.Web.UI.WebControls.Button dollarbut;
		protected System.Web.UI.WebControls.TextBox euro;
		protected System.Web.UI.WebControls.Button eurobut;
		protected System.Web.UI.WebControls.TextBox result;
		Currency c ;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			
			base.OnInit(e);
			
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.c = new ServiceClient.localhost.Currency();
			this.dollarbut.Click += new System.EventHandler(this.dollarbut_Click);
			this.eurobut.Click += new System.EventHandler(this.eurobut_Click);
			// 
			// c
			// 
			this.c.Credentials = null;
			this.c.Url = "http://localhost/SampleService/Service1.asmx";
			this.c.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; MS Web Services Client Protocol 1.0.3705.0)";

		}
		#endregion

		private void dollarbut_Click ( object sender, System.EventArgs e )
		{
			float f = float.Parse ( dollar.Text ) ;
			float r = c.DollarToRupees ( f ) ;
			result.Text = r.ToString() ;
		}

		private void eurobut_Click(object sender, System.EventArgs e)
		{
			float f = float.Parse ( euro.Text ) ;
			float r = c.EuroToRupees ( f ) ;
			result.Text = r.ToString() ;	
		}
	}
}
