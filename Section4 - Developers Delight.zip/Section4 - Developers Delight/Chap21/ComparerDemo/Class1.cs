using System ;
using System.Collections ; 

namespace icomb
{
	class emp 
	{
		public string name ;
		public int id ;
		public float balance ;
		public emp ( int i, string n, float b) 
		{
			id = i ;
			name = 	n ;
			balance = b ;
		}
		public new string ToString( )
		{
			return id + " " + name + " " + balance ;

		}
	}
	public class mysort : IComparer
	{
		public int Compare ( object a, object b )
		{
			int i1 = ( ( emp ) a ).id ;
			int i2 = ( ( emp ) b ).id ;
			string n1 = ( ( emp ) a ).name ;
			string n2 = ( ( emp ) b ).name ;
			if ( i1 == i2 )
			{
				return n1.CompareTo ( n2 ) ;
			}
			if ( i1 < i2 )
				return -1 ;
			return 1 ;
		}
	}
	public class Class1
	{
		public static int Main ( string[ ] args )
		{
			emp[ ] e = 
			{
				new emp ( 2, "Sanjay", 3450 ),
				new emp ( 1, "Rahul", 2500 ) ,
				new emp ( 10, "Kavita", 10000 ),
				new emp ( 9, "Mohit", 25000),
				new emp ( 6, "Sapna", 2500),
			} ;

			mysort s = new mysort( ) ;
			Array.Sort ( e, s ) ;
			foreach ( emp s1 in e )
				Console.WriteLine ( s1.ToString( ) ) ;

			return 0 ;
		}
	}
}
