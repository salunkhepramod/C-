1] fontandcolor

The 'fontandcolor' application demonstartes the use of two common dialog controls namely a 'FontDialog' and a 'ColorDialog'. 

On running this application a window would popup with two menus namely 'Font' and 'Color' If you click 'Font' menu a Font dialog would appear. 
Select the font, font style,color etc. from this dialog. On clicking 'OK' button of the 'FontDialog', a 'Hello' message would get displayed in the selected font.
 
On clicking the 'Color' menu a 'ColorDialog' would get dislpayed. On clicking 'OK' button of the 'ColorDialog', the same 'Hello' message would get dislpayed in the color that you have selected.

2] CopyFile

The 'CopyFile' program makes use of the 'OpenFileDialog' control. On executing this program, a window would popup with a menu as 'CopyFile'. On clicking this menu, a dialogbox
with a text box, a combobox and a 'Copy' button would get displayed. You can type the path of the file to be copied in the textbox. If you want, you can use 'Browse' button to search and select a file to be copied. Choose the drive name where the file has to be copied, from the combobox. Clicking on 'Copy' button would copy the file to the selected drive.

3] DeleteFile

The 'DeleteFile' program also makes use of the 'OpenFileDialog' control. If you run this program, a window with a 'DelFile' would get displayed. On selecting this menu a dialogbox would popup.

You can type the name of the file to be deleted in the textbox. To search a file click on the
'Search' button. Select the '.txt' file from the filedialog displayed. The name of the file 
thus selected would get shown in the textbox. Click on 'Delete' button to delete this file.