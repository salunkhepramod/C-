using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using fontassembly ;

namespace fontclient
{
	public class myform : System.Windows.Forms.Form
	{
		private System.ComponentModel.Container components = null;
		Random r = new Random() ;

        mytext t = new mytext() ;
		public myform()
		{
			InitializeComponent();
		}
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(336, 317);
			this.Name = "myform";
			this.Text = "Draw Text";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.myform_MouseDown);

		}
		#endregion
		[STAThread]
		static void Main() 
		{ 
			Application.Run(new myform());
		}
		private void myform_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if ( e.Button == MouseButtons.Left )
			{
				Point pt  = new Point ( e.X, e.Y ) ;
				t.display ( this, "Hello", Color.Red, "Comic Sans MS", 30, pt ) ;
			}
		}
	}
}
