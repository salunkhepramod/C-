1] CSharpClass

The 'CSharpClass' is a class library containing a C# class

2] VBClass

The 'VBClass' program contains a class written in VB .NET. We have derived this class from the class defined in CSharpClass.

3] langinterop

The 'langinterop' program is a console application demonstrating the Language Interoperability feature of .NET. The class in this program is derived from the the class defined in VBClass. Hence in the 'langiterop' console application we have called the functions of 'CSharpClass' and 'VBClass'. 