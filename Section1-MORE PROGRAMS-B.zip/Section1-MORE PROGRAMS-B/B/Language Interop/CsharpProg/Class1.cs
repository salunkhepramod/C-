using System;
using VBProg;
namespace CsharpProg
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// 
	class csharpclass : myvbclass 
	{
		public void func4()
		{
			Console.WriteLine ( "In Func4 of C# class" ) ;
		}

		static void Main(string[] args)
		{
			csharpclass c = new csharpclass() ;
			
			c.func1() ;
			c.func2() ;
			c.func3() ;
			c.func4() ;
		}
	}
}
