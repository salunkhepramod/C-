using System ;
using System.Collections ;

namespace collect
{
	class Class1
	{
		static void Main ( string[ ] args )
		{
			Queue q  = new Queue( ) ;

			q.Enqueue ( "Message1" ) ;
			q.Enqueue ( "Message2" ) ;
			q.Enqueue ( "Message3" ) ;
			q.Enqueue ( "Message4" ) ;

			Console.WriteLine ( "First message: {0}", q.Dequeue( ) ) ;

			Console.WriteLine ( "The element at the head is {0}", q.Peek( ) )  ;

			IEnumerator e = q.GetEnumerator( ) ;
			while ( e.MoveNext( ) )
				Console.WriteLine ( e.Current ) ;
		}
	}
}
