Bow and Arrow is a game based on multithreading. When you run this program a window would get displayed. In this window you will find a bitmap of a shooter. 

In few seconds after running this application some coloured baloons would appear at the 
bottom of the window. These ballons would move up slowly. 

When the balloons arrive in the range of the player, he has to shoot the balloons by clicking the left mouse button. 

On clicking the left mouse button an arrow would get catapulated in the direction of balloons which would puncture the balloons.