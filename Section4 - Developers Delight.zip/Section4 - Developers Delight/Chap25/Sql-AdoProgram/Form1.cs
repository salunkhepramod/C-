using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient ;

namespace AdoProgram1
{
	class bank
	{
		private SqlDataAdapter adpt ;
		private DataSet ds ;
		private DataTable dt ;

		public bank()
		{
			//string constr = @"server = prakash\NetSDK ; database = bank ; uid = sa ; pwd = " ;
			string constr = @"server=PRAKASH;database=bank;uid=sa;pwd=kicit" ;
			string cmdstr = "SELECT accno, name, bal from account" ;
			adpt= new SqlDataAdapter ( cmdstr, constr ) ;

			SqlCommandBuilder b = new SqlCommandBuilder ( adpt ) ;
			ds = new DataSet( ) ;
			adpt.Fill ( ds, "account" ) ;
			dt = ds.Tables["account"] ;	
		}

		public void  addrec ( int  id, String  name, int  bal )
		{
			DataRow r = getrowbyid ( id ) ;
			if ( r == null )
			{
				r = dt.NewRow() ;
				r[0] = id ;
				r[1] = name ;
				r[2] = bal ; 
				dt.Rows.Add ( r ) ;
		 		adpt.Update ( ds, "account" ) ;	
			}
			else
			{
				MessageBox.Show ( "Record Already Exists" ) ;
			}
		}

		public void  deleterec ( int  id )
		{
			string exp = " accno = " + id ;
			DataRow[ ] r  = dt.Select ( exp ) ;
			r[0].Delete() ;
			adpt.Update ( ds, "account" ) ;
		}

		public void  updaterec ( int  id, String  name, int    bal ) 
		{
			string exp = " accno = " + id ;
			DataRow[] r  = dt.Select ( exp ) ;
			r[0][1] = name ;
			r[0][2] = bal ;
			adpt.Update ( ds, "account" ) ; 
		}

		public DataRow getrowbyid ( int  id ) 
		{
			try
			{
				string exp = "accno =" + id ;
				DataRow[] r  = dt.Select ( exp ) ;
				return r[0] ;
			}
			catch ( Exception e )
			{
				return null ;
			}
		}
		public DataSet dset
		{
			get 
			{
				return ds ;
			}
		}
	}
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox name;
		private System.Windows.Forms.TextBox bal;
		private System.Windows.Forms.TextBox acc;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private bank b = new bank() ;
		private int m_oper ;
		private System.Windows.Forms.DataGrid dgrid;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button add;
		private System.Windows.Forms.Button update;
		private System.Windows.Forms.Button delete;
		private System.Windows.Forms.Button commit;
		private System.Windows.Forms.Button search;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			m_oper = 0 ;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			dgrid.SetDataBinding ( b.dset, "account" ) ;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing ) ;
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.name = new System.Windows.Forms.TextBox();
			this.add = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.update = new System.Windows.Forms.Button();
			this.delete = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.commit = new System.Windows.Forms.Button();
			this.bal = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.acc = new System.Windows.Forms.TextBox();
			this.dgrid = new System.Windows.Forms.DataGrid();
			this.label1 = new System.Windows.Forms.Label();
			this.search = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgrid)).BeginInit();
			this.SuspendLayout();
			// 
			// name
			// 
			this.name.Enabled = false;
			this.name.Location = new System.Drawing.Point(72, 64);
			this.name.Name = "name";
			this.name.Size = new System.Drawing.Size(104, 20);
			this.name.TabIndex = 6;
			this.name.Text = "";
			// 
			// add
			// 
			this.add.Location = new System.Drawing.Point(24, 32);
			this.add.Name = "add";
			this.add.TabIndex = 0;
			this.add.Text = "Add";
			this.add.Click += new System.EventHandler(this.addbut_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.add,
																					this.update,
																					this.delete});
			this.groupBox1.Location = new System.Drawing.Point(216, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.groupBox1.Size = new System.Drawing.Size(120, 144);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Operations";
			// 
			// update
			// 
			this.update.Location = new System.Drawing.Point(24, 64);
			this.update.Name = "update";
			this.update.TabIndex = 1;
			this.update.Text = "Update";
			this.update.Click += new System.EventHandler(this.updatebut_Click);
			// 
			// delete
			// 
			this.delete.Location = new System.Drawing.Point(24, 96);
			this.delete.Name = "delete";
			this.delete.TabIndex = 2;
			this.delete.Text = "Delete";
			this.delete.Click += new System.EventHandler(this.delbut_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Location = new System.Drawing.Point(8, 16);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(184, 144);
			this.groupBox2.TabIndex = 17;
			this.groupBox2.TabStop = false;
			// 
			// commit
			// 
			this.commit.Enabled = false;
			this.commit.Location = new System.Drawing.Point(48, 128);
			this.commit.Name = "commit";
			this.commit.TabIndex = 15;
			this.commit.Text = "Commit";
			this.commit.Click += new System.EventHandler(this.commit_Click);
			// 
			// bal
			// 
			this.bal.Enabled = false;
			this.bal.Location = new System.Drawing.Point(72, 96);
			this.bal.Name = "bal";
			this.bal.Size = new System.Drawing.Size(104, 20);
			this.bal.TabIndex = 7;
			this.bal.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 9;
			this.label2.Text = "Name";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Balance";
			// 
			// acc
			// 
			this.acc.Enabled = false;
			this.acc.Location = new System.Drawing.Point(72, 32);
			this.acc.Name = "acc";
			this.acc.Size = new System.Drawing.Size(40, 20);
			this.acc.TabIndex = 5;
			this.acc.Text = "";
			// 
			// dgrid
			// 
			this.dgrid.DataMember = "";
			this.dgrid.Location = new System.Drawing.Point(32, 176);
			this.dgrid.Name = "dgrid";
			this.dgrid.ReadOnly = true;
			this.dgrid.Size = new System.Drawing.Size(280, 128);
			this.dgrid.TabIndex = 16;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 23);
			this.label1.TabIndex = 8;
			this.label1.Text = "Acc No";
			// 
			// search
			// 
			this.search.Enabled = false;
			this.search.Location = new System.Drawing.Point(120, 32);
			this.search.Name = "search";
			this.search.Size = new System.Drawing.Size(56, 23);
			this.search.TabIndex = 11;
			this.search.Text = "Search";
			this.search.Click += new System.EventHandler(this.search_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 325);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dgrid,
																		  this.commit,
																		  this.search,
																		  this.label3,
																		  this.label2,
																		  this.label1,
																		  this.bal,
																		  this.name,
																		  this.acc,
																		  this.groupBox1,
																		  this.groupBox2});
			this.Name = "Form1";
			this.Text = "Bank";
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main ( ) 
		{
			Application.Run ( new Form1 ( ) ) ;
		}
		private void search_Click ( object sender, System.EventArgs e )
		{
	
			DataRow r = b.getrowbyid ( Int32.Parse ( acc.Text ) ) ; 
			if ( r != null ) 
			{
				name.Text = r[1].ToString() ;
				bal.Text = r[2].ToString() ;
				name.Enabled = true ;
				bal.Enabled = true ;
			}
			else
				MessageBox.Show ( "Record not found" ) ;
		}
		private void addbut_Click ( object sender, System.EventArgs e )
		{
			acc.Enabled = true ;
			name.Enabled = true ;
			bal.Enabled = true ;
			commit.Enabled = true ;
			search.Enabled = false ;
			m_oper = 1 ;
		}
		private void updatebut_Click ( object sender, System.EventArgs e )
		{
			acc.Enabled = true ;
			name.Enabled = false ;
			bal.Enabled = false ;
			commit.Enabled = true ;
			search.Enabled = true ;
			m_oper = 2 ;
		}
		private void delbut_Click ( object sender, System.EventArgs e )
		{
			acc.Enabled = true ;
			name.Enabled = false ;
			bal.Enabled = false ;
			commit.Enabled = true ;
			search.Enabled = true ;
			m_oper = 3 ;
		}
		private void commit_Click ( object sender, System.EventArgs e )
		{
			int a = Int32.Parse ( acc.Text ) ;
			string n = name.Text ;
			int balance = Int32.Parse ( bal.Text ) ;
			switch ( m_oper )
			{
				case 1:
					b.addrec ( a, n,  balance ) ;						
					break ;
				case 2:
					b.updaterec ( a, n,  balance ) ;	
					break ;
				case 3:
					b.deleterec ( a ) ;
					break ;
			}
			acc.Text = "" ;
			name.Text = "" ;
			bal.Text = "" ;
			commit.Enabled = false ;
			search.Enabled = false ;
			acc.Enabled = false ;
			name.Enabled = false ;
			bal.Enabled = false ;
		}
	}
}
