using System;
using System.Runtime.InteropServices ;
using System.Reflection ;
namespace latebinding
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Type t ;
			t = Type.GetTypeFromProgID("AtlServer.Math");		
			object o = Activator.CreateInstance(t) ;
			object r1 =  t.InvokeMember("Add",BindingFlags.InvokeMethod, null,o,new object[]{15,20}) ; 
			int i = int.Parse( r1.ToString() ) ;
			Console.WriteLine ( i) ;
			object r2 =  t.InvokeMember("Sub",BindingFlags.InvokeMethod, null,o,new object[]{15,20}) ; 
			i = int.Parse( r2.ToString() ) ;
			Console.WriteLine ( i) ;
		}
	}
}
