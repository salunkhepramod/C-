Webbrowser

The 'webbrowser' would enable you to explore the web pages. On executing this application a WinForm window would appear. Clicking on 'Go' button would display the home page of the 'www.funducode.com' site in the browser window.

The toolbar buttons like 'Back','Forward' would allow you to navigate between the web pages. You can type any other URL in the textbox labelled with 'url'.