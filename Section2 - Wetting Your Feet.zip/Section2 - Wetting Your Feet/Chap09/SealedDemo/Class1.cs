using System;
namespace Company
{
	sealed class b
	{
		int i ;

		public void display( )
		{
			Console.WriteLine ( i ) ; 
		}
	}

	class x : b
	{
		int j ;
		
		public void display( )
		{
			Console.WriteLine ( j ) ; 
		}
	}
}
