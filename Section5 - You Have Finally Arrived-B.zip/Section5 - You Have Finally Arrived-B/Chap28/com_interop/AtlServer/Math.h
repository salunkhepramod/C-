// Math.h : Declaration of the CMath

#pragma once
#include "resource.h"       // main symbols


// IMath
[
	object,
	uuid("8678E5AE-5F7E-4B12-927C-C435F53D88A9"),
	dual,	helpstring("IMath Interface"),
	pointer_default(unique)
]
__interface IMath : IDispatch
{
	[id(1), helpstring("method Add")] HRESULT Add([in] int n1, [in] int n2, [out,retval] int * n3);
	[id(2), helpstring("method Sub")] HRESULT Sub([in] int n1, [in] int n2, [out,retval] int * n3);
};



// CMath

[
	coclass,
	threading("apartment"),
	vi_progid("AtlServer.Math"),
	progid("AtlServer.Math.1"),
	version(1.0),
	uuid("6902391B-C3F4-4425-8287-D8070A3BBE7F"),
	helpstring("Math Class")
]
class ATL_NO_VTABLE CMath : public IMath
{
public:
	CMath()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(Add)(int n1, int n2, int * n3);
	STDMETHOD(Sub)(int n1, int n2, int * n3);
};

