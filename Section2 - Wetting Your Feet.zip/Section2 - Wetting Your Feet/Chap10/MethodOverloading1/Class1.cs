using System ;
namespace Demo
{
	class sample
	{
		public int abs ( int ii )
		{
			return ( ii > 0 ? ii : ii * -1 ) ;
		}

		public long abs ( long ll )
		{
			return ( ll > 0 ? ll : ll * -1 ) ;
		}

		public double abs ( double dd )
		{
			return ( dd > 0 ? dd : dd * -1 ) ;
		}
	}

	class Class1
	{
		static void Main ( string [ ] args )
		{
			int i = -25, j ;
			long l = -100000L, m ;
			double d = -12.34, e ;

			sample s = new sample( ) ;
			j = s.abs ( i ) ;
			m = s.abs ( l ) ;
			e = s.abs ( d ) ; 

			Console.WriteLine ( j + " " + m + " " +  e ) ;
		}
	}
}
