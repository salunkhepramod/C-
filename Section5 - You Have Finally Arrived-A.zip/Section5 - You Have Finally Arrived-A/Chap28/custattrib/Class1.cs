using System ;
using System.IO ;
using System.Reflection ;

enum devstage { Beta1, Beta2, Final } ;

[ AttributeUsage ( AttributeTargets.Class ) ]
class Readme : Attribute
{
	public string author ;
	public string comment ;
	public devstage stage ; 
	public Readme ( string a )
	{
		author = a ;
	}
}

class myreadme
{
	public myreadme( )
	{
		Type t = GetType( ) ;
		foreach ( Attribute a in t.GetCustomAttributes ( true ) )
		{
			Readme r = ( Readme ) a ;
			Console.WriteLine ( r.author ) ;
			Console.WriteLine ( r.comment ) ;
			Console.WriteLine ( r.stage ) ;
		}
	}
}

[ Readme ( "Nitin", comment = "This is class test1", stage = devstage.Beta1 ) ]
class test1 : myreadme
{
}

[ Readme ( "Rahul", comment = "This is class test2", stage = devstage.Beta2 ) ]
class test2 : myreadme
{
}

namespace Sample
{
	class Class1
	{
		public static void Main ( String[] args )
		{
			test1 t1 = new test1() ;
			test2 t2 = new test2() ;
		}
	}
}