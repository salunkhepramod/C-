using System ;
using System.Data ;
using System.Data.SqlClient ;
namespace Sample
{
	class myclass
	{
		static void Main ( string[ ] args )
		{
			string constr = @"server = prakash\NetSDK ; database = bank ; uid = sa ; pwd = " ;
			string cmdstr = "Insert into account values ( 98, 'Aakash', 25000 )" ;
			SqlConnection con = new SqlConnection ( constr ) ;
			SqlCommand com = new SqlCommand ( cmdstr, con ) ;
			con.Open( ) ;

			com.ExecuteNonQuery ( ) ;

			con.Close( ) ;
		}
	}
}
