using System ;
namespace Overloading
{
	class complex
	{
		int real, imag ;

		public complex ( int r, int i )
		{
			real = r ;
			imag = i ;
		}

		public static complex operator + ( complex p , complex q )
		{
			complex r = new complex ( p.real + q.real, p.imag + q.imag ) ;
			return r ;
		}

		public static complex operator ++ ( complex p )
		{
			complex r = new complex ( p.real + 1, p.imag + 1 ) ;
			return r ;
		}

		public static bool operator < ( complex p, complex q )
		{
			if ( p.real < q.real )
				return true ;
			else
				return false ;
		}

		public static bool operator > ( complex p, complex q )
		{
			if ( p.real < q.real )
				return true ;
			else
				return false ;
		}

		public void showdata( )
		{
			Console.WriteLine ( real + " " + imag + "i" ) ;
		}
	}

	class Class1
	{
		static void Main ( string[ ] args )
		{
			complex c1 = new complex ( 10, 10 ) ;
			complex c2 = new complex ( 20, 20 ) ;

			complex c3 = c1 + c2 ;
			Console.Write ( "Contents of c3: " ) ;
			c3.showdata( ) ;

			complex c4 = ++c1 ; 
	
			if ( c4 < c1 )
				Console.WriteLine ( "c4 is less than c1" ) ;
			else
				Console.WriteLine ( "c4 is greater than c1" ) ;

			c4 += c1 ;
			Console.Write ( "Contents of c4: " ) ;
			c4.showdata( ) ;

			c4 = c1++ ;
			Console.Write ( "Contents of c4: " ) ;
			c4.showdata( ) ;
		}
	}
}
