Image Viewer

The 'imageviewer' is an image explorer application. 

On executing this application, a window would popup. In this window you will find a tree view control, a list view control and a picture control. 

The tree view control would display the drives like 'C:\', 'D:\' etc. The user must click on the drive to expand it and select a folder.

If the folder contains any '.bmp', ',jpg', '.gif' files, then they would get displayed in the list view control. 

Now, if the user clicks on any filename in the list view control, the image in that file would get displayed the the picture control.