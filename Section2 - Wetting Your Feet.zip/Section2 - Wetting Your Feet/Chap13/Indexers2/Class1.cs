using System;
namespace sample
{
	public class array
	{
		int [ ] arr1 = new int [ ] { 12, 34, 5, 6, 7, 88, 22 } ;

		int [ , ] arr2  = new int [ , ] { 
								{ 12, 34, 5, 6 },
								{ 7, 88, 22, 2 }
										} ;

		public int this [ int index ]
		{
			get
			{
				return arr1 [ index ] ;
			}
			set
			{
				arr1 [ index ] = value ;
			}
		}

		public int this [ int index1, int index2 ]
		{
			get
			{
				return arr2 [ index1,index2 ] ;
			}
			set
			{
				arr2 [ index1,index2 ] = value ;
			}
		}
	}
	class Class1
	{
		static void Main ( string[ ] args )
		{
			array a = new array( ) ;
			a [ 3 ] = 43 ;
			a [ 0, 2 ] = 89 ;
		}
	}
}
