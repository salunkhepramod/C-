using System ;
namespace sample
{
	public class window
	{
		static int height ;
		public static int Height
		{
			get
			{
				return height ;
			}
			set
			{
				height = value ;
			}
		}
	}
	class Class1
	{
		static void Main ( string[ ] args )
		{
			window.Height = 10 ;
			Console.WriteLine ( "Window height: " + window.Height ) ;
		}
	}
}

