using System ;
using System.Data ;
using System.Data.SqlClient ;

namespace sample
{
	class Class1
	{
		static void Main ( string [ ] args )
		{
			string constr = @"server = prakash\NetSDK ; database = bank ; uid = sa ; pwd = " ;
			string cmdstr = "SELECT accno, name, balance from account" ;
			SqlConnection con = new SqlConnection ( constr ) ;
			SqlCommand com = new SqlCommand ( cmdstr, con ) ;
			con.Open( ) ;

			SqlDataReader r = com.ExecuteReader( ) ;

			while ( r.Read ( ) )
				Console.WriteLine ( r [ 0 ] + "  " + r [ 1 ] + "  " + r [ 2 ] ) ;
			con.Close( ) ;
		}
	}
}

