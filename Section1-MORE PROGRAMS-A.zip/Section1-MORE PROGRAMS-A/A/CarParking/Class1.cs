using  System ;
public class parking
{
	static public void Main ( string [ ] args )
	{
		int  choice ;
		string  type ;
		int  number, row = 0, col = 0 ;
		int [ ] tarr ;
		car [ , ] c = new car [ 2 , 10 ] ;
		scooter [ , ] sc = new scooter [ 2 , 10 ] ;		
		bool  finish = true ;
		while ( finish )
		{
			Console.WriteLine( "Car Parking" ) ;
			Console.WriteLine( "1. Arrival" ) ;
			Console.WriteLine( "2. Departure" ) ;
			Console.WriteLine( "3. Display" ) ;
			Console.WriteLine ( "4. Total cars" ) ;
			Console.WriteLine ( "5. Total Scooters" ) ;
			Console.WriteLine ( "6. Total Vehicles" ) ;
			Console.WriteLine ( "7. exit" ) ; 
			choice = Int32.Parse ( Console.ReadLine( ) ) ;

			switch ( choice )
			{
				case  1:  
					Console.WriteLine ( "Add :" ) ;
					Console.WriteLine ( "Enter Vehicle Type: " ) ;
					type = Console.ReadLine( ).ToLower( ) ;
					Console.WriteLine ( "Enter Vehicle Number: " ) ;
					number = Int32.Parse(Console.ReadLine( ) );
					if ( type.Equals ( "car" ) )
					{
						tarr = car.getfreerowcol( ) ;
						row = tarr [ 0 ] ;
						col = tarr [ 1 ] ;
						c [ row, col ] = new car ( number, row, col ) ;
						c [ row, col ].add( ) ;
					}
					else
					{
						if ( type.Equals ( "scooter" ) )
						{
							tarr = scooter.getfreerowcol( ) ;
							row = tarr [ 0 ] ;
							col = tarr [ 1 ] ;
							sc [ row - 2, col ] = new scooter ( number, row, col ) ;
							sc [ row - 2, col ].add( ) ;
						}
						else
						{
							Console.WriteLine ( "invalid type" ) ;
							break ;
						}
					}
					break ;
				case 2:
					Console.WriteLine ( "Departure" ) ;
					Console.WriteLine ( "Enter vehicle type: " ) ;
					type = Console.ReadLine( ).ToLower( ) ;
					Console.WriteLine ( "Enter Number: " ) ;
					number = Int32.Parse(Console.ReadLine( ) ) ;
					if ( type.Equals ( "car" ) )
					{
						tarr = car.getrcbyinfo ( number ) ;
						row = tarr[0] ;
						col =tarr[1] ;
						c [ row, col ].delete( ) ;
						for ( int  i = col ; i < 9 ; i++ )
							c[row,i] = c[row,i+1 ] ;
						c[row,col] = null ;
					}
					else
					{
						tarr = scooter.getrcbyinfo ( number ) ;
						row = tarr[0] - 2 ;
						col =tarr[1] ;
						sc [ row, col ].delete( ) ;
						for ( int  i = col ; i < 9 ; i++ )
							sc [ row, i ] = sc[row,i+1 ] ;
						sc [ row, col ] = null ;
					}
					break ;
				case  3:
					Console.WriteLine ( "Display" ) ;
					vehicle.display( ) ;
					break ;
				case  4:
					 Console.WriteLine ( "Total Cars: " + car.getcarcount( ) ) ;
					break ;
				case  5:
					 Console.WriteLine ( "Total Scooters :" + scooter.getscootcount( ) ) ;
					break ;
				case  6:
					 Console.WriteLine ( "Total Vehicles :" + vehicle.getvcount( ) ) ;
					break ;
				case  7:
					finish = false ;
					break ;
			}
		}
	}	
}


class vehicle
{
	protected static  int  [ , ] parkinfo = new  int[ 4, 10 ] ;
	protected int  num, row, col ;
	protected static  int  vehcount ;
	public static void display( )
	{
		for ( int  c = 0 ; c < 10 ; c++ )
			Console.WriteLine ( parkinfo[ 0, c ] + " " + parkinfo[ 1, c ] + " " +						parkinfo[ 2, c ] + " " + parkinfo[ 3, c ] ) ;
	}
	public static int getvcount( )
	{
		return vehcount ;
	}
}
class car : vehicle
{
	static  int  carcount ;

	public car ( int  n, int  r, int  c )
	{
		num = n ;
		row = r ;
		col = c ;
	}
	public void add( )
	{
		carcount++ ;
		vehcount++ ;
		parkinfo[ row, col ] = num ;
	}
	public void delete( )
	{
		int  c ;
		for (  c = col ; c < 9 ; c++ )
			parkinfo [ row, c ] = parkinfo [ row, c+1 ] ;
		parkinfo [ row, c ] = 0 ;
		carcount-- ;
		vehcount-- ;
	}
	public static  int[ ]  getfreerowcol( )
	{
		int  i ;
		int  fcol, scol ;
		int  [ ] arr = new int [ 2 ] ;
		for ( i = 0 ; i < 10 ; i++ )
		{
			if ( parkinfo[0,i] == 0 )
				break ;
		}
		fcol = i ;
		for ( i = 0 ; i < 10 ; i++ )
		{
			if ( parkinfo [ 1, i ] == 0 )
				break ;
		}
		scol = i ;
		if ( fcol > scol )
		{
			arr[ 0 ] =  1 ;
			arr[ 1 ] = scol ;
		}
		else
		{
			arr [ 0 ] =  0 ;
			arr [ 1 ] = fcol ;
		}
		return  arr ;
	}
	public 	static int[ ] getrcbyinfo ( int info )
	{
		int  [ ] arr = new int [ 2 ] ;
		int  found = 0 ;
		for ( int  r = 0 ; r < 2 ; r++ )
		{
			for ( int  c = 0 ; c < 10 ; c++ )
			{
				if ( parkinfo [ r, c ] == info)
				{
					arr [ 0 ] = r ;
					arr [ 1 ] = c ;
					found = 1 ;
					break ;
				}
			}
			if ( found == 1 )
				break ;
		}
		return  arr ;   
	}
	public static int getcarcount( )
	{
		return carcount ;
	}
}  // end of class

class scooter : vehicle
{
	static int scootcount ;
	public scooter ( int  n, int r, int c )
	{
		num = n ;
		row = r ;
		col = c ;
	}
	public void add( )
	{
		parkinfo[ row, col ] = num ;
		scootcount++ ;
		vehcount++ ;
	}
	public void delete( )
	{
		parkinfo[ row, col ] = 0;
		scootcount-- ;
		vehcount-- ;
	}
	public static int[ ] getfreerowcol( )
	{
		int [ ] arr = new int[ 2 ] ;
		int  found = 0 ;
		for ( int  r = 2 ; r < 4 ; r++ )
		{
			for ( int  c = 0 ; c < 10 ; c++ )
			{
				if ( parkinfo[ r, c ] == 0 )
				{
					arr[ 0 ] = r ;
					arr[ 1 ] = c ;
					found = 1 ;
					break ;
				}
			}
			if ( found == 1 )
				break ;
		}
		return arr ;
	}
	public static int[ ] getrcbyinfo ( int info )
	{
		int [ ] arr = new int[ 2 ] ;
		int  found = 0 ;
		for ( int  r = 2 ; r < 4 ; r++ )
		{
			for ( int  c = 0 ; c < 10 ; c++ )
			{
				if ( parkinfo[ r, c ] == info )
				{
					arr[ 0 ] = r ;
					arr[ 1 ] = c ;
					found = 1 ;
					break ;
				}
			}
			if ( found == 1 )
				break ;
		}
		return arr ;   
	}
	public static int getscootcount( )
	{
		return scootcount ;
	}
}










