using System ;
class onedarray
{
	static void Main ( string[ ] args )
	{
		int[ ] arr1 = new int [ 5 ] { 1, 4, 7, 8, 9 } ;
		int[ ] arr2 = new int [ 10 ] ;

		arr1.CopyTo ( arr2, 0 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;
		Console.WriteLine( ) ;

		arr2.SetValue ( 5, 0 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;
		Console.WriteLine( ) ;

		Console.WriteLine ( "Number of elements in arr1:" + arr1.Length ) ;
		Console.WriteLine ( "Number of elements in arr2:" + arr2.Length ) ;

		Array.Copy ( arr1, 2, arr2, 6, 2 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;
		Console.WriteLine( ) ;

		Array.Reverse ( arr2 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " ") ;
		Console.WriteLine( ) ;

		Array.Sort ( arr2 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;
		Console.WriteLine( ) ;

		Console.WriteLine ( "Index of 8 is " + Array.IndexOf ( arr2, 8 ) ) ;

		Array.Clear ( arr2, 3, 3 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;
		Console.WriteLine( ) ;
	}
}
