using System;
using System.Net ;
using System.IO;
using System.Text;

namespace Sample
{
	public class Class1
	{
		public static int Main ( string[] args )
		{
			WebRequest req = WebRequest.Create ( " http://kicit/funducode/default.htm" ) ;
			WebResponse resp = req.GetResponse( ) ;

			Stream s = resp.GetResponseStream( ) ;
			StreamReader sr = new StreamReader ( s, Encoding.ASCII ) ;
			char [] buff = new char[1024] ;
			int bytes = 0 ;

			//Read from the stream and write any data to the console
			bytes = sr.Read( buff, 0, 1024) ;
			while( bytes > 0 ) 
			{
				Console.Write ( buff ) ;
				bytes = sr.Read ( buff, 0, 1024 ) ;
			}
			sr.Close( );
			return 0;
		}
	}
}
