using System ;
namespace Bank
{
	class customer
	{
		string name ;
		int accno ;
		int balance ;

		public customer ( string n, int a, int b ) 
		{
			name = n ;
			accno = a ;
			balance = b ;
		}

		public void withdraw ( int amt )
		{
			if ( balance - amt <= 100 )
				throw new bankexception ( accno, balance ) ;
			balance -= amt ;
		}

		public int getbalance( )
		{
			return balance ;
		}
	}

	class bankexception : Exception
	{
		int acc ;
		int bal ;

		public bankexception ( int a, int b )
		{
			acc = a ;
			bal = b ;
		}
		public void inform( )
		{
			Console.WriteLine ( "Account Number: " + acc + "Balance left: " + bal ) ;
		}
	}

	public class Class1
	{
		static void Main ( string[ ] args )
		{
			customer c = new customer ( "Rahul", 2453, 500 ) ;
			try
			{
				c.withdraw ( 450 ) ;
			}
			catch ( bankexception e )
			{
				Console.WriteLine ( "Transaction Failed " ) ;
				e.inform( ) ;
			}
		}
	}
}
