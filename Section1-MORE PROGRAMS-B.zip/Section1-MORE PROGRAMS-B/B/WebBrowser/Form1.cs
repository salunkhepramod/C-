using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WebBrowser1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.StatusBar statusBar1;
		private AxSHDocVw.AxWebBrowser browser;
		private System.Windows.Forms.TextBox url;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button go;
		private System.Windows.Forms.ToolBar toolBar1;
		private System.Windows.Forms.ToolBarButton Back;
		private System.Windows.Forms.ToolBarButton Forward;
		private System.Windows.Forms.ToolBarButton Refresh;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();
			object arg1 = 0, arg2 = ""; object arg3 = ""; object arg4 = "";
			browser.Navigate ( url.Text, ref arg1, ref arg2, ref arg3, ref arg4 ) ;
		}
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.browser = new AxSHDocVw.AxWebBrowser();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.url = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.go = new System.Windows.Forms.Button();
			this.toolBar1 = new System.Windows.Forms.ToolBar();
			this.Back = new System.Windows.Forms.ToolBarButton();
			this.Forward = new System.Windows.Forms.ToolBarButton();
			this.Refresh = new System.Windows.Forms.ToolBarButton();
			((System.ComponentModel.ISupportInitialize)(this.browser)).BeginInit();
			this.SuspendLayout();
			// 
			// browser
			// 
			this.browser.Enabled = true;
			this.browser.Location = new System.Drawing.Point(0, 104);
			this.browser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("browser.OcxState")));
			this.browser.Size = new System.Drawing.Size(584, 344);
			this.browser.TabIndex = 0;
			this.browser.TitleChange += new AxSHDocVw.DWebBrowserEvents2_TitleChangeEventHandler(this.browser_TitleChange);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 423);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(584, 22);
			this.statusBar1.TabIndex = 3;
			this.statusBar1.Text = "statusBar1";
			// 
			// url
			// 
			this.url.Location = new System.Drawing.Point(48, 64);
			this.url.Name = "url";
			this.url.Size = new System.Drawing.Size(464, 20);
			this.url.TabIndex = 4;
			this.url.Text = "http://kicit/funducode/";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 64);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(32, 23);
			this.label1.TabIndex = 5;
			this.label1.Text = "Link";
			// 
			// go
			// 
			this.go.Location = new System.Drawing.Point(520, 64);
			this.go.Name = "go";
			this.go.Size = new System.Drawing.Size(48, 23);
			this.go.TabIndex = 6;
			this.go.Text = "Go";
			this.go.Click += new System.EventHandler(this.go_Click);
			// 
			// toolBar1
			// 
			this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.Back,
																						this.Forward,
																						this.Refresh});
			this.toolBar1.ButtonSize = new System.Drawing.Size(50, 50);
			this.toolBar1.DropDownArrows = true;
			this.toolBar1.Name = "toolBar1";
			this.toolBar1.ShowToolTips = true;
			this.toolBar1.Size = new System.Drawing.Size(584, 53);
			this.toolBar1.TabIndex = 7;
			this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
			// 
			// Back
			// 
			this.Back.Text = "Back";
			// 
			// Forward
			// 
			this.Forward.Text = "Forward";
			// 
			// Refresh
			// 
			this.Refresh.Text = "Refresh";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(584, 445);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.toolBar1,
																		  this.go,
																		  this.label1,
																		  this.url,
																		  this.statusBar1,
																		  this.browser});
			this.Name = "Form1";
			this.Text = "Web Browser";
			((System.ComponentModel.ISupportInitialize)(this.browser)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void go_Click(object sender, System.EventArgs e)
		{
			object arg1 = 0, arg2 = ""; object arg3 = ""; object arg4 = "";
			browser.Navigate ( url.Text, ref arg1, ref arg2, ref arg3, ref arg4 ) ;
		}

		private void browser_TitleChange(object sender, AxSHDocVw.DWebBrowserEvents2_TitleChangeEvent e)
		{
			statusBar1.Text = e.text ;
			this.Text = e.text ;
		}

		private void toolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			ToolBar.ToolBarButtonCollection b = toolBar1.Buttons ;
			int index = b.IndexOf ( e.Button ) ;

			switch ( index )
			{
				case 0:
					browser.GoBack() ;
					break ;
				case 1:
					browser.GoForward() ;
					break ;
				case 2:
					browser.Refresh();
					break ;
			}
		}
	}
}
