using System ;
namespace Shape
{
	class cone
	{
		float height, radius ;

		public void setdata ( float h, float r ) 
		{
			height = h ;
			radius = r ;
		}

		public void displaydata( ) 
		{
			Console.WriteLine ( "Height = " + height ) ;
			Console.WriteLine ( "Radius = " + radius ) ;
		}

		public void volume( )
		{
			float v ;
			v = ( 1 / 3.0f ) * 3.14f * radius * radius * height ;
			Console.WriteLine ( "Volume = " + v ) ;
		}
	}

	class Class1
	{
		static void Main ( string [ ] args )
		{
			cone c1 = new cone( ) ;
			cone c2 = new cone( ) ;
	
			c1.setdata ( 10.0f, 3.5f ) ;
			c1.displaydata( ) ;
			c1.volume( ) ;

			c2.setdata ( 20.0f, 6.2f ) ;
			c2.displaydata( ) ;
			c2.volume( ) ;
		}
	}
}
