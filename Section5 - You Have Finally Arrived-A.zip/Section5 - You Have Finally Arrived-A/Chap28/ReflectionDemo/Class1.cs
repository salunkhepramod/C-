using System ;
using System.Reflection ;

namespace Sample
{
	public class test :  MarshalByRefObject
	{
		int i ;
		int prop;
		public int Prop
		{
			get
			{
				return prop ;		
			}
			set
			{
				prop = value ;	
			}
		}
		public test()
		{}
		public test ( int x )
		{
			i = x ;
		}
		public int myfunc ( int x )
		{
			Console.WriteLine ( "In myfunc " + x ) ;
			return 2 * x ;
		}
	}

	class Class1
	{
		static void Main ( string[] args )
		{
			Type t = typeof ( test ) ;

			Console.WriteLine ( "Type of class: " + t ) ;
			Console.WriteLine ( "Namespace: " + t.Namespace ) ;

			ConstructorInfo[] ci = t.GetConstructors( );
			Console.WriteLine ( "Constructors are:" ) ;
			foreach ( ConstructorInfo c in ci )
				Console.WriteLine( c ) ;
	
			PropertyInfo[] pi = t.GetProperties( );
			Console.WriteLine( "Properties are:" ) ;
			foreach( PropertyInfo p in pi )
				Console.WriteLine( p ) ;
			
			MethodInfo[] mi = t.GetMethods( ) ;
			Console.WriteLine( "Methods are:" ) ;
			foreach ( MethodInfo m in mi )
			{
				if ( t == m.DeclaringType ) 
				{
					Console.WriteLine( "Name: " + m.Name  ) ;
					ParameterInfo[] pif = m.GetParameters () ;
					foreach ( ParameterInfo p in pif )
					{
						Console.WriteLine ( "Type: " + p.ParameterType  ) ;
						Console.WriteLine ( "Parameter Name: " + p.Name ) ;
					}
				}
			}
		}
	}
}
