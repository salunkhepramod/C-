udpchatting

The 'udpchatting' program is based on UDP protocol. It also uses .NET socket classes. This application enables the communication between computers that are connected in a network. 

This application must be running on all those computers that you want to involve in communication.

On executing this application, an icon would get displayed on the system tray. Right click on this icon. A context menu would popup with two options 'Send' and 'Exit'.

If you click 'Send' option, a 'sendform' dialogbox would popup. Type in the message in the textbox, and enter the name of computer to which the message has to be sent. Then click on 'Send' button. A small green colored frameless message-window would popup on the desktop of  
the computer to whom the messsage has been sent.

A context menu has been provided with this message-window. You can edit (cut/copy/paste) the messages in this window by selecting the options from the context menu. 

The 'send to' option would send the message from the current computer to the computer you specify in the 'sendform' dialogbox. Chose 'Exit' option from the context menu provided with the system tray icon to terminate the program.