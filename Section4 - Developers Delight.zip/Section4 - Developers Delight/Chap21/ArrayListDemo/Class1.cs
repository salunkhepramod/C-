using System;
using System.Collections;
namespace ArrayListDemo
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
			ArrayList arr  = new ArrayList( ) ;

			arr.Add ( 'a' ) ;
			arr.Add ( 43 ) ;
			arr.Add ( 6.7 ) ;
			arr.Add ( "Rahul" ) ;

			arr.Insert ( 1, "Deepti" ) ; 

			for ( int i = 0 ; i < arr.Count ; i++ )
				Console.WriteLine ( arr [ i ] ) ;
		}
	}
}
