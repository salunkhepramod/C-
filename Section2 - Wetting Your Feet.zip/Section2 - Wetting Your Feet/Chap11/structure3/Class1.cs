using System ;
namespace sample
{
	class myclass
	{
		public int i ;
	}
	class Class1
	{
		static void Main ( string[ ] args )
		{
			myclass x = new myclass( ) ;
			x.i = 9 ;

			myclass y ;
			y = x ;

			y.i = 5 ;
			Console.WriteLine ( x.i ) ; 			
			Console.WriteLine ( y.i ) ;
		}
	}
}
