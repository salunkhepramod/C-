using System ;
using System.Data ;
using System.Data.SqlClient ;
namespace sample
{
	class Class1
	{
		static void Main ( string [ ] args )
		{
			string constr = @"server = prakash\NetSDK ; database = bank ; uid = sa ; pwd = " ;
			string cmdstr = "SELECT accno, name, balance from account" ;
	
			SqlDataAdapter dest= new SqlDataAdapter ( cmdstr, constr ) ;

			DataSet ds = new DataSet( ) ;
			dest.Fill ( ds, "account" ) ;
			DataTable dt = ds.Tables [ "account" ] ;
			DataRow row = dt.NewRow( ) ;
			row [ 0 ] = 9 ;
			row [ 1 ] = "Janaki" ;
			row [ 2 ] = 76000 ;

			dt.Rows.Add ( row ) ;

			SqlCommandBuilder mybuilder = new SqlCommandBuilder ( dest ) ;
			dest.Update ( ds, "account" ) ;
		}
	}
}
