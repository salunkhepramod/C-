using System;
using System.Net;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net.Sockets;
using System.Threading ;

namespace udpchat
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem Send;
		private System.Windows.Forms.MenuItem Exit;
		private System.ComponentModel.IContainer components;
		private UdpClient server ;
		private IPEndPoint recvpt ;
		private int port = 200 ;
		private sendform mysendform ;
		private noteform mynoteform ;
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			mysendform = new sendform();
			server = new UdpClient(port);
			
			IPHostEntry iph = Dns.Resolve ( Dns.GetHostName() ) ;
			IPAddress[]  ipa = iph.AddressList ;
			recvpt = new IPEndPoint ( ipa[0], port ) ;
			Thread svthread = new Thread ( new ThreadStart ( startserver ) ) ;
			svthread.Start( ) ;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
			server.Close( ) ;
			mysendform.Close();

		}

		public void showmyform()
		{
			mynoteform.ShowDialog();	
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.Send = new System.Windows.Forms.MenuItem();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.Exit = new System.Windows.Forms.MenuItem();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			// 
			// Send
			// 
			this.Send.Index = 0;
			this.Send.Text = "Send";
			this.Send.Click += new System.EventHandler(this.Send_Click);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.Send,
																						 this.Exit});
			// 
			// Exit
			// 
			this.Exit.Index = 1;
			this.Exit.Text = "Exit";
			this.Exit.Click += new System.EventHandler(this.Exit_Click);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.ContextMenu = this.contextMenu1;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "notifyIcon1";
			this.notifyIcon1.Visible = true;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(136, 165);
			this.Name = "Form1";
			this.ShowInTaskbar = false;
			this.Text = "Form1";
			this.WindowState = System.Windows.Forms.FormWindowState.Minimized;

		}
		#endregion

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Exit_Click(object sender, System.EventArgs e)
		{
			this.Dispose( );
		}
		public void startserver( )
		{
			do
			{
				byte[] data = server.Receive ( ref recvpt ) ;
				System.Text.ASCIIEncoding encode = new System.Text.ASCIIEncoding ( ) ;
				string str = encode.GetString ( data ) ;
				string sub = str.Substring ( str.LastIndexOf ( '@' ) + 1 ) ;
				mynoteform = new noteform();
				mynoteform.MyStr = sub ;
				string mainmsg = str.Substring ( 0, str.LastIndexOf ( '@' ) ) ;
				mynoteform.messagebox.Text= mainmsg ;
				Thread t = new Thread ( new ThreadStart ( showmyform ) ) ;	
				t.Start() ;
			} while ( true ) ;
		}
		private void Send_Click(object sender, System.EventArgs e)
		{
			mysendform.ShowDialog( ) ; 
		}

		
	}
}
