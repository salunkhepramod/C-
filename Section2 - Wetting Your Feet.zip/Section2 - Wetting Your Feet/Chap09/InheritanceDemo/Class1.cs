using System;
namespace Company
{
	class publisher
	{
		string title ;
		float price ;
	
		public publisher ( string t, float p )
		{
			title = t ;
			price = p ;
		}

		public void displaydata( )
		{
			Console.WriteLine ( "Title: " + title ) ; 
			Console.WriteLine ( "Price: " + price ) ; 
		}
	}

	class book : publisher
	{
		int pagecount ;
		
		public book ( string t, float p, int c ) : base ( t, p )
		{
			pagecount = c ;
		}

		public void displaydata( )
		{
			base.displaydata( ) ;
			Console.WriteLine ( "Total Pages: " + pagecount ) ; 
		}
	}

	class Class1
	{
		static void Main ( string[ ] args )
		{
			book b = new book ( "Let Us C#", 180, 475 ) ;
			b.displaydata( ) ;
		}
	}
}
