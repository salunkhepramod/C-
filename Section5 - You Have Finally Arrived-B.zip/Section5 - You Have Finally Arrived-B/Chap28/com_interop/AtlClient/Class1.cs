using System;
using AtlServer ;
namespace AtlClient
{
	class Class1
	{
		[STAThread]
		static void Main ( string[] args )
		{
			CMath m = new CMath() ;
			Console.WriteLine ( m.Add ( 10, 20 ) );
			Console.WriteLine ( m.Sub ( 10, 20 ) );
		}
	}
}
