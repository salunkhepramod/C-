using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace copyfiledlg
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Form2 : System.Windows.Forms.Form
	{
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.TextBox TextBox1;
		public System.Windows.Forms.Button BrowseButton;
		public System.Windows.Forms.Button CopyButton;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.ComboBox comboBox1;
		OpenFileDialog od ;

		public Form2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Label1 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.TextBox1 = new System.Windows.Forms.TextBox();
			this.BrowseButton = new System.Windows.Forms.Button();
			this.CopyButton = new System.Windows.Forms.Button();
			this.od = new System.Windows.Forms.OpenFileDialog();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(8, 24);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(72, 23);
			this.Label1.TabIndex = 0;
			this.Label1.Text = "Source :";
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(8, 56);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(64, 23);
			this.Label2.TabIndex = 1;
			this.Label2.Text = "Target :";
			// 
			// TextBox1
			// 
			this.TextBox1.Location = new System.Drawing.Point(88, 24);
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.Size = new System.Drawing.Size(144, 20);
			this.TextBox1.TabIndex = 2;
			this.TextBox1.Text = "Enter source file name";
			// 
			// BrowseButton
			// 
			this.BrowseButton.Location = new System.Drawing.Point(248, 24);
			this.BrowseButton.Name = "BrowseButton";
			this.BrowseButton.TabIndex = 4;
			this.BrowseButton.Text = "Browse";
			this.BrowseButton.Click += new System.EventHandler(this.BrowseButton_Click);
			// 
			// CopyButton
			// 
			this.CopyButton.Location = new System.Drawing.Point(112, 88);
			this.CopyButton.Name = "CopyButton";
			this.CopyButton.TabIndex = 5;
			this.CopyButton.Text = "Copy";
			this.CopyButton.Click += new System.EventHandler(this.CopyButton_Click);
			// 
			// comboBox1
			// 
			this.comboBox1.Items.AddRange(new object[] {
														   "C:\\",
														   "D:\\"});
			this.comboBox1.Location = new System.Drawing.Point(88, 56);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(121, 21);
			this.comboBox1.TabIndex = 6;
			this.comboBox1.Text = "comboBox1";
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(344, 125);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.comboBox1,
																		  this.CopyButton,
																		  this.BrowseButton,
																		  this.TextBox1,
																		  this.Label2,
																		  this.Label1});
			this.Name = "Form2";
			this.Text = "Form2";
			this.ResumeLayout(false);

		}
		#endregion

		private void CopyButton_Click(object sender, System.EventArgs e)
		{
			FileInfo file = new FileInfo ( od.FileName ) ;
			String str =  comboBox1.Text ;
			String s =  TextBox1.Text ;
			int l = s.LastIndexOf ( '\\' ) ; 
			s  = s.Remove  ( 0, l + 1 ) ;
			str = String.Concat ( str, s ) ;
			String msg = String.Concat ( "File Copied to ", comboBox1.Text ) ;
			msg = String.Concat ( msg, " successfully" ) ;
			try
			{
				file.CopyTo ( str, true ) ;
				MessageBox.Show ( msg ) ;
			}
			catch ( Exception ex)
			{
				MessageBox.Show ( "Unable to copy file" ) ;
			}

		}

		private void BrowseButton_Click(object sender, System.EventArgs e)
		{
			od.Filter = "*.txt|*.*||"  ;
			od.InitialDirectory = "C:\\"  ;
			od.ShowDialog( ) ;
			TextBox1.Text = od.FileName ;
		}

	}
}
