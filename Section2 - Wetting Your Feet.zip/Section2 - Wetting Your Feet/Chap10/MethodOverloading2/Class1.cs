using System ;
namespace Demo
{
	class sample
	{

		public void f ( int  i )
		{
		}

		public void f ( float  f ) 
		{
		}	

		public void f ( int  i, float  f )
		{
		}
	}
	
	class Class1
	{
		static void Main ( string [ ] args )
		{
			sample s = new sample( ) ;
			s.f ( 10 ) ;
			s.f ( 3.5f ) ;
			s.f ( 10, 3.5f ) ;
		}
	}
}
