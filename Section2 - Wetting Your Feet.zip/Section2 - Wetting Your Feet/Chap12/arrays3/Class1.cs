using System ;
class jaggedarray
{
	static void Main ( string[ ] args )
	{
		int [ ][ ] arr1 = new int [ 2 ] [ ] ;
		arr1 [ 0 ] = new int [ 3 ] { 1, 2, 3 } ;
		arr1 [ 1 ] = new int [ 2 ] { 4, 5 } ;

		Console.WriteLine ( "Elements of arr1: " ) ;
		for ( int i = 0 ; i < arr1.Length ; i++ )
		{
			for ( int j = 0 ; j < arr1[ i ].Length ; j++ )
				Console.Write ( arr1 [ i ] [ j ] ) ;
			Console.WriteLine( ) ;
		}
	}
}
