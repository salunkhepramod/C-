using System ;
using System.Data ;
using System.Data.OleDb ;

namespace sample
{
	class Class1
	{
		static void Main ( string[ ] args )
		{
			string constr = " Provider = Microsoft.Jet.OLEDB.4.0; Data Source = c:\\bank.mdb " ;
			string cmdstr = "SELECT accno, name, balance from account" ;

			OleDbConnection con = new OleDbConnection ( constr ) ;
			OleDbCommand com = new OleDbCommand ( cmdstr, con ) ;
			con.Open( ) ;
		
			OleDbDataReader r = com.ExecuteReader( ) ;
			while ( r.Read ( ) )
				Console.WriteLine ( r [ 0 ] + "  " + r [ 1 ] + "  " + r [ 2 ] ) ;

			con.Close( ) ;
		
		}
	}
}
