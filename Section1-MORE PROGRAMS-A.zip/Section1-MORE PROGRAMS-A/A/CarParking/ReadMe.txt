Carparking is a simple console application that demonstrates the use of 2D-array.

When you run this program a menu would get displayed with following options.

1. Arrival
2. Departure
3. Display
4. Total cars
5. Total Scooters
6. Total Vehicles
7. exit

You are supposed to enter your choice as 1, 2, 3.... etc. On selecting option 1, you would be asked to enter the type of vehicle arrived. The type of vehicle that can be entered here is either a 'car' or a 'scooter'. 

Next you would be asked to enter the vehicle
number. The data entered, would get stored in an array. 

On selecting option 2, you would be asked to enter the type of vehicle given above and then 
the number of the vehicle. If the vehicle exists then its data would get deleted from the array.

On selecting option 3, a list of vehicle numbers that have been stored in an array would get
displayed in a tabular form.

If you select option 4 the total number of cars parked would get displayed.

If you select option 5 the total number of scooters parked would get displayed.

And if you select option 6 the total number of vehicles would get displayed. 

Selecting option 7 would terminate the program.