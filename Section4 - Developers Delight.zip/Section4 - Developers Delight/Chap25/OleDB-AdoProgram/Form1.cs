using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb ;

namespace AdoProgram1
{
	class bank
	{
		OleDbDataAdapter adpt ;
		DataSet ds ;
		DataTable dt ;
		public bank( )
		{
			string str=" Data Source=c:\\bank.mdb; Provider = Microsoft.Jet.OLEDB.4.0";
			string cmd = "SELECT accno, name, balance from account" ;
			adpt= new OleDbDataAdapter( cmd, str ) ;
			OleDbCommandBuilder obd = new OleDbCommandBuilder( adpt ) ;
			ds = new DataSet() ;
			adpt.Fill ( ds, "account" ) ;
			dt = ds.Tables["account"] ;	
		}
		public void  addnewrec ( int  id, String  name, int  bal )
		{
			DataRow r = getrowbyid ( id ) ;
			if ( r == null )
			{
				r = dt.NewRow() ;
				r[0] = id ;
				r[1] = name ;
				r[2] = bal ; 
				dt.Rows.Add ( r ) ;
				adpt.Update ( ds, "account" ) ;	
			}
			else
			{
				MessageBox.Show ( "Record Already Exists" ) ;
			}
		}
		public void  deleterec ( int  id )
		{
			string exp = " accno = " + id ;
			DataRow[] r  = dt.Select ( exp ) ;
			r[0].Delete() ;
			adpt.Update ( ds, "account" ) ;
		}
		public void  updaterec ( int  id, String  name, int    bal ) 
		{
			string exp = " accno = " + id ;
			DataRow[] r  = dt.Select ( exp ) ;
			r[0][1] = name ;
			r[0][2] = bal ;
			adpt.Update ( ds, "account" ) ; 
		}
		public DataRow getrowbyid ( int  id ) 
		{
			try
			{
				string exp = " accno =" + id ;
				DataRow[] r  = dt.Select ( exp ) ;
				return r[0] ;
			}
			catch ( Exception e )
			{
				return null ;
			}
		}
		/*public DataRow[] getrowsbysort ( string val ) 
		{
			string filter = val  + " desc";
			try
			{
				DataRow[] r  = dt.Select ( "", filter  ) ;
				return r ;
			}
			catch ( Exception e )
			{
				return null ;
			}
		}*/
		public DataSet dset
		{
			get 
			{
				return ds ;
			}
		}
	}
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox name;
		private System.Windows.Forms.TextBox bal;
		private System.Windows.Forms.TextBox acc;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button searchbut;
		private bank b = new bank() ;
		private int m_oper ;
		private System.Windows.Forms.Button commitbut;
		private System.Windows.Forms.DataGrid dgrid;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button addbut;
		private System.Windows.Forms.Button updatebut;
		private System.Windows.Forms.Button delbut;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			m_oper = 0 ;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			dgrid.SetDataBinding ( b.dset, "account" ) ;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing ) ;
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.acc = new System.Windows.Forms.TextBox();
			this.addbut = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.updatebut = new System.Windows.Forms.Button();
			this.delbut = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.searchbut = new System.Windows.Forms.Button();
			this.commitbut = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.bal = new System.Windows.Forms.TextBox();
			this.dgrid = new System.Windows.Forms.DataGrid();
			this.name = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgrid)).BeginInit();
			this.SuspendLayout();
			// 
			// acc
			// 
			this.acc.Enabled = false;
			this.acc.Location = new System.Drawing.Point(72, 32);
			this.acc.Name = "acc";
			this.acc.Size = new System.Drawing.Size(40, 20);
			this.acc.TabIndex = 5;
			this.acc.Text = "";
			// 
			// addbut
			// 
			this.addbut.Location = new System.Drawing.Point(24, 32);
			this.addbut.Name = "addbut";
			this.addbut.TabIndex = 0;
			this.addbut.Text = "Add";
			this.addbut.Click += new System.EventHandler(this.addbut_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.addbut,
																					this.updatebut,
																					this.delbut});
			this.groupBox1.Location = new System.Drawing.Point(216, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.groupBox1.Size = new System.Drawing.Size(120, 144);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Operations";
			// 
			// updatebut
			// 
			this.updatebut.Location = new System.Drawing.Point(24, 64);
			this.updatebut.Name = "updatebut";
			this.updatebut.TabIndex = 1;
			this.updatebut.Text = "Update";
			this.updatebut.Click += new System.EventHandler(this.updatebut_Click);
			// 
			// delbut
			// 
			this.delbut.Location = new System.Drawing.Point(24, 96);
			this.delbut.Name = "delbut";
			this.delbut.TabIndex = 2;
			this.delbut.Text = "Delete";
			this.delbut.Click += new System.EventHandler(this.delbut_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Location = new System.Drawing.Point(8, 16);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(184, 144);
			this.groupBox2.TabIndex = 17;
			this.groupBox2.TabStop = false;
			// 
			// searchbut
			// 
			this.searchbut.Enabled = false;
			this.searchbut.Location = new System.Drawing.Point(120, 32);
			this.searchbut.Name = "searchbut";
			this.searchbut.Size = new System.Drawing.Size(56, 23);
			this.searchbut.TabIndex = 11;
			this.searchbut.Text = "Search";
			this.searchbut.Click += new System.EventHandler(this.searchbut_Click);
			// 
			// commitbut
			// 
			this.commitbut.Enabled = false;
			this.commitbut.Location = new System.Drawing.Point(48, 128);
			this.commitbut.Name = "commitbut";
			this.commitbut.TabIndex = 15;
			this.commitbut.Text = "Commit";
			this.commitbut.Click += new System.EventHandler(this.commitbut_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 23);
			this.label1.TabIndex = 8;
			this.label1.Text = "Acc No";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 9;
			this.label2.Text = "Name";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Balance";
			// 
			// bal
			// 
			this.bal.Enabled = false;
			this.bal.Location = new System.Drawing.Point(72, 96);
			this.bal.Name = "bal";
			this.bal.Size = new System.Drawing.Size(104, 20);
			this.bal.TabIndex = 7;
			this.bal.Text = "";
			// 
			// dgrid
			// 
			this.dgrid.DataMember = "";
			this.dgrid.Location = new System.Drawing.Point(32, 176);
			this.dgrid.Name = "dgrid";
			this.dgrid.ReadOnly = true;
			this.dgrid.Size = new System.Drawing.Size(280, 128);
			this.dgrid.TabIndex = 16;
			// 
			// name
			// 
			this.name.Enabled = false;
			this.name.Location = new System.Drawing.Point(72, 64);
			this.name.Name = "name";
			this.name.Size = new System.Drawing.Size(104, 20);
			this.name.TabIndex = 6;
			this.name.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 325);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dgrid,
																		  this.commitbut,
																		  this.searchbut,
																		  this.label3,
																		  this.label2,
																		  this.label1,
																		  this.bal,
																		  this.name,
																		  this.acc,
																		  this.groupBox1,
																		  this.groupBox2});
			this.Name = "Form1";
			this.Text = "Bank";
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main ( ) 
		{
			Application.Run ( new Form1 ( ) ) ;
		}
		private void searchbut_Click ( object sender, System.EventArgs e )
		{
	
			DataRow r = b.getrowbyid ( Int32.Parse ( acc.Text ) ) ; 
			if ( r != null ) 
			{
				name.Text = r[1].ToString() ;
				bal.Text = r[2].ToString() ;
				name.Enabled = true ;
				bal.Enabled = true ;
			}
			else
				MessageBox.Show ( "Record not found" ) ;
		}
		private void addbut_Click ( object sender, System.EventArgs e )
		{
			acc.Enabled = true ;
			name.Enabled = true ;
			bal.Enabled = true ;
			commitbut.Enabled = true ;
			searchbut.Enabled = false ;
			m_oper = 1 ;
		}
		private void updatebut_Click ( object sender, System.EventArgs e )
		{
			acc.Enabled = true ;
			name.Enabled = false ;
			bal.Enabled = false ;
			commitbut.Enabled = true ;
			searchbut.Enabled = true ;
			m_oper = 2 ;
		}
		private void delbut_Click ( object sender, System.EventArgs e )
		{
			acc.Enabled = true ;
			name.Enabled = false ;
			bal.Enabled = false ;
			commitbut.Enabled = true ;
			searchbut.Enabled = true ;
			m_oper = 3 ;
		}
		private void commitbut_Click ( object sender, System.EventArgs e )
		{
			int a = Int32.Parse ( acc.Text ) ;
			string n = name.Text ;
			int balance = Int32.Parse ( bal.Text ) ;
			switch ( m_oper )
			{
				case 1:
					b.addnewrec ( a, n,  balance ) ;						
					break ;
				case 2:
					b.updaterec ( a, n,  balance ) ;	
					break ;
				case 3:
					b.deleterec ( a ) ;
					break ;
			}
			acc.Text = "" ;
			name.Text = "" ;
			bal.Text = "" ;
			commitbut.Enabled = false ;
			searchbut.Enabled = false ;
			acc.Enabled = false ;
			name.Enabled = false ;
			bal.Enabled = false ;
		}
	}
}
