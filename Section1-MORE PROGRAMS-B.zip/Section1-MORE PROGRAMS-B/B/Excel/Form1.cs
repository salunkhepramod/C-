using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace excelclient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(80, 56);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(264, 149);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			Excel.Application excel = new Excel.Application() ;
			int rowIndex = 1 ;
			int colIndex =  0 ;

			Excel.Workbook book = excel.Workbooks.Add( Excel.XlSheetType.xlWorksheet ) ;
			Excel.Worksheet sh = (Excel.Worksheet) excel.ActiveSheet ;
			sh.Name = "Account Info" ;
			

			/*m_allbooks = m_excel -> Workbooks ;
			m_book  = m_allbooks -> Add ( ( long ) xlWorksheet ) ;
			m_sheet = m_excel -> ActiveSheet ;
			m_sheet -> Name = "Market Share!" ;

			m_sheet -> Range[ "A2" ] -> Value = "Company A" ;*/

			string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source = c:\\bank.mdb " ;
			string cmdstr = "SELECT * from account" ;

			OleDbDataAdapter adapter= new OleDbDataAdapter ( cmdstr, constr ) ;

			DataSet ds = new DataSet();
			adapter.Fill ( ds, "account" ) ;

			DataTable table = ds.Tables[0] ;

			foreach ( DataColumn col in table.Columns )
			{
				colIndex++ ;	
				excel.Cells [ 1, colIndex ] = col.ColumnName ;				
			}
			foreach(DataRow row in table.Rows)
			{
				rowIndex++ ;
				colIndex = 0 ;
				foreach ( DataColumn col in table.Columns )
				{
					colIndex++;
					excel.Cells [ rowIndex, colIndex ] = row[col.ColumnName].ToString();
				}
			}
			//Excel.Chart c = book.Charts.Add( ;
			//c.ChartWizard(
/*			m_range  = m_sheet -> Range[ "A2:D3" ] ;
			m_chart  = m_book -> Charts -> Add( ) ;		

			HRESULT hr = m_chart -> ChartWizard ( ( Range * ) m_range,( long ) 
				xl3DPie, 7L, ( long ) xlRows, 1L, 0L, 1L, "Market Share" ) ;*/

			excel.Visible = true;	
			//excel.Save("c:\\test.xls");
		}
	}
}
