namespace  fileoperation
{
	using System ;
	using System.IO ;
	
	class Class1
	{
		static void Main ( string[ ] args )
		{
			string  str1 = "The .NET Revolution" ;
			string  str2 = "Long live C# " ;
			string  str3 = "Targeting the internet" ;

			StreamWriter  sw = new  StreamWriter ( "file2.txt", false ) ;
			sw.WriteLine ( str1 ) ;
			sw.WriteLine ( str2 ) ;
			sw.WriteLine ( str3 ) ;
			sw.Close( ) ;

			StreamReader  sr = new  StreamReader ( "file2.txt" ) ;

			string  str ;
			do
			{
				str = sr.ReadLine( ) ;
				Console.WriteLine( str ) ;
			} while ( str != null ) ; 
			sr.Close( ) ;
		}
	}
}
