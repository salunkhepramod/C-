using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading ;
using System.IO ;

namespace FileSearching
{
	class search
	{
		Label file ;
		DirectoryInfo dir ;

		public search ( Label l, string p )
		{
			file = l ;
			dir = new DirectoryInfo ( p ) ;
		}

		public void searchfiles( )
		{
			FileSystemInfo[] f = dir.GetFileSystemInfos( ) ;
			foreach ( FileSystemInfo i in f )
			{
				if ( i.Attributes == FileAttributes.Directory )
				{
					dir = new DirectoryInfo ( i.FullName ) ;
					searchfiles( ) ;
				}
				else
					file.Text = i.FullName ;
			}
		}
	}

	public class Form1 : System.Windows.Forms.Form
	{
		Thread t ;

		private System.Windows.Forms.Button start;
		private System.Windows.Forms.Button stop;
		private System.Windows.Forms.Button close;
		public System.Windows.Forms.Label file;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponentll
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.file = new System.Windows.Forms.Label();
			this.stop = new System.Windows.Forms.Button();
			this.close = new System.Windows.Forms.Button();
			this.start = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// file
			// 
			this.file.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.file.Location = new System.Drawing.Point(16, 32);
			this.file.Name = "file";
			this.file.Size = new System.Drawing.Size(280, 40);
			this.file.TabIndex = 0;
			// 
			// stop
			// 
			this.stop.Location = new System.Drawing.Point(144, 112);
			this.stop.Name = "stop";
			this.stop.TabIndex = 1;
			this.stop.Text = "Stop";
			this.stop.Click += new System.EventHandler(this.stop_Click);
			// 
			// close
			// 
			this.close.Location = new System.Drawing.Point(256, 112);
			this.close.Name = "close";
			this.close.TabIndex = 2;
			this.close.Tag = "";
			this.close.Text = "Close";
			this.close.Click += new System.EventHandler(this.close_Click);
			// 
			// start
			// 
			this.start.Location = new System.Drawing.Point(32, 112);
			this.start.Name = "start";
			this.start.TabIndex = 0;
			this.start.Text = "Start";
			this.start.Click += new System.EventHandler(this.start_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 149);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.file,
																		  this.close,
																		  this.stop,
																		  this.start});
			this.Name = "Form1";
			this.Text = "File Search";
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	
		private void start_Click ( object sender, System.EventArgs e )
		{
			string path = @"c:\" ;
			search s = new search ( file, path ) ;

	        ThreadStart ts = new ThreadStart ( s.searchfiles ) ;
			t = new Thread  ( ts ) ;
			t.Start( ) ;
		}

		private void stop_Click(object sender, System.EventArgs e)
		{
			t.Abort() ;
		}

		private void close_Click(object sender, System.EventArgs e)
		{
			Dispose( ) ;
		}
	}
}
