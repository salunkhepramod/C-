using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace employee
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RadioButton female;
		private System.Windows.Forms.TextBox age;
		private System.Windows.Forms.TextBox name;
		private System.Windows.Forms.ComboBox sal;
		private System.Windows.Forms.ListBox exp;
		private System.Windows.Forms.RadioButton male;
		private System.Windows.Forms.Button ok;
		private System.Windows.Forms.Label lname;
		private System.Windows.Forms.Label lage;
		private System.Windows.Forms.Label lsal;
		private System.Windows.Forms.GroupBox gender;
		private System.Windows.Forms.GroupBox experience;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			sal.SelectedIndex = 0 ;
			exp.SelectedIndex = 0;


			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent( )
		{
			this.ok = new System.Windows.Forms.Button();
			this.sal = new System.Windows.Forms.ComboBox();
			this.exp = new System.Windows.Forms.ListBox();
			this.lname = new System.Windows.Forms.Label();
			this.male = new System.Windows.Forms.RadioButton();
			this.lage = new System.Windows.Forms.Label();
			this.lsal = new System.Windows.Forms.Label();
			this.gender = new System.Windows.Forms.GroupBox();
			this.female = new System.Windows.Forms.RadioButton();
			this.age = new System.Windows.Forms.TextBox();
			this.name = new System.Windows.Forms.TextBox();
			this.experience = new System.Windows.Forms.GroupBox();
			this.gender.SuspendLayout();
			this.experience.SuspendLayout();
			this.SuspendLayout();
			// 
			// ok
			// 
			this.ok.Location = new System.Drawing.Point(224, 232);
			this.ok.Name = "ok";
			this.ok.Size = new System.Drawing.Size(72, 24);
			this.ok.TabIndex = 8;
			this.ok.Text = "OK";
			this.ok.Click += new System.EventHandler(this.ok_Click);
			// 
			// sal
			// 
			this.sal.DropDownWidth = 152;
			this.sal.Items.AddRange(new object[] {
													 "2500",
													 "3500",
													 "5000",
													 "10000",
													 "20000"});
			this.sal.Location = new System.Drawing.Point(64, 120);
			this.sal.Name = "sal";
			this.sal.Size = new System.Drawing.Size(88, 21);
			this.sal.TabIndex = 5;
			// 
			// exp
			// 
			this.exp.Items.AddRange(new object[] {
													 "Less than a year",
													 "1 - 2 yrs",
													 "2 - 5 yrs",
													 "more than 5 yrs"});
			this.exp.Location = new System.Drawing.Point(16, 24);
			this.exp.Name = "exp";
			this.exp.Size = new System.Drawing.Size(120, 108);
			this.exp.TabIndex = 0;
			// 
			// lname
			// 
			this.lname.Location = new System.Drawing.Point(16, 24);
			this.lname.Name = "lname";
			this.lname.Size = new System.Drawing.Size(40, 24);
			this.lname.TabIndex = 0;
			this.lname.Text = "Name:";
			// 
			// male
			// 
			this.male.Location = new System.Drawing.Point(8, 24);
			this.male.Name = "male";
			this.male.Size = new System.Drawing.Size(72, 24);
			this.male.TabIndex = 0;
			this.male.Text = "Male";
			// 
			// lage
			// 
			this.lage.Location = new System.Drawing.Point(16, 72);
			this.lage.Name = "lage";
			this.lage.Size = new System.Drawing.Size(32, 23);
			this.lage.TabIndex = 2;
			this.lage.Text = "Age:";
			// 
			// lsal
			// 
			this.lsal.Location = new System.Drawing.Point(16, 120);
			this.lsal.Name = "lsal";
			this.lsal.Size = new System.Drawing.Size(40, 23);
			this.lsal.TabIndex = 4;
			this.lsal.Text = "Salary:";
			// 
			// gender
			// 
			this.gender.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.female,
																				 this.male});
			this.gender.Location = new System.Drawing.Point(64, 160);
			this.gender.Name = "gender";
			this.gender.Size = new System.Drawing.Size(88, 100);
			this.gender.TabIndex = 6;
			this.gender.TabStop = false;
			this.gender.Text = "Gender";
			// 
			// female
			// 
			this.female.Location = new System.Drawing.Point(8, 64);
			this.female.Name = "female";
			this.female.Size = new System.Drawing.Size(64, 16);
			this.female.TabIndex = 1;
			this.female.Text = "Female";
			// 
			// age
			// 
			this.age.Location = new System.Drawing.Point(64, 72);
			this.age.Name = "age";
			this.age.Size = new System.Drawing.Size(64, 20);
			this.age.TabIndex = 3;
			this.age.Text = "";
			// 
			// name
			// 
			this.name.Location = new System.Drawing.Point(64, 24);
			this.name.Name = "name";
			this.name.Size = new System.Drawing.Size(272, 20);
			this.name.TabIndex = 1;
			this.name.Text = "";
			// 
			// experience
			// 
			this.experience.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.exp});
			this.experience.Location = new System.Drawing.Point(184, 72);
			this.experience.Name = "experience";
			this.experience.Size = new System.Drawing.Size(152, 144);
			this.experience.TabIndex = 7;
			this.experience.TabStop = false;
			this.experience.Text = "Experience";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 285);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lsal,
																		  this.lage,
																		  this.lname,
																		  this.ok,
																		  this.experience,
																		  this.gender,
																		  this.sal,
																		  this.age,
																		  this.name});
			this.Name = "Form1";
			this.Text = "Employee";
			this.gender.ResumeLayout(false);
			this.experience.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void ok_Click(object sender, System.EventArgs e)
		{
			string str1,str = "Name:           " + name.Text +"\n" ;
			str += "Age:              " + age.Text + "\n" ;
			str += "Salary:          " + sal.Text + "\n" ;
			str += "Experience:  " + exp.Text+ "\n" ;
			if( male.Checked == true )
				str1 = "male" ;
			else
				str1 = "female" ;
			str += "Gender:        " + str1 ;
			MessageBox.Show( str,"Emp Information" ) ;

		}

		

	

		
	}
}
