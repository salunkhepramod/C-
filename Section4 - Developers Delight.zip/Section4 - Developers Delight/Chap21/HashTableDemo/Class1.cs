using System ;
using System.Collections ;

namespace collect
{
	class Class1
	{
		static void Main ( string[ ] args )
		{
			Hashtable h = new Hashtable( ) ;
			h.Add ( "mo", "Monday" ) ;
			h.Add ( "tu", "Tuesday" ) ;
			h.Add ( "we", "Wednesday" ) ;
			h.Add ( "th", "Thursday" ) ;
			h.Add ( "fr", "Friday" ) ;
			h.Add ( "sa", "Saturday" ) ;
			h.Add ( "su", "Sunday" ) ;

			IDictionaryEnumerator e = h.GetEnumerator( ) ;
			while ( e.MoveNext( ) )
				Console.WriteLine ( e.Key + "\t" + e.Value ) ;

			Console.WriteLine ( "The Keys are : " ) ;
			ICollection k = h.Keys ;
			foreach ( object i in k )
				Console.WriteLine ( i ) ;

			Console.WriteLine ( "The Values are : " ) ;
			ICollection v = h.Values ;
			foreach ( object i in v )
				Console.WriteLine ( i ) ;
		}
	}
}
