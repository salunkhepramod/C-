using System ;
class rectarray
{
	static void Main ( string[ ] args )
	{
		int [ , ] arr1 = new int [ 2, 3 ] { { 1, 2, 3 }, { 4, 5, 6 } } ;
		int [ , ] arr2 = new int [ 2, 3 ] ;

		Console.WriteLine ( "Elements of arr1: " ) ;
		for ( int i = 0 ; i < arr1.GetLength( 0 ) ; i++ )
		{
			for ( int j = 0 ; j < arr1.GetLength( 1 ) ; j++ )
				Console.Write ( arr1 [ i, j ] ) ;
			Console.WriteLine( ) ;
		}

		Console.WriteLine ( "Number of elements in arr1: " + arr1.Length ) ;

		Array.Copy ( arr1, 2, arr2, 2, 3 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;

		arr2.SetValue ( 5, 0, 1 ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i + " " ) ;

		Array.Clear ( arr2, 0, arr2.Length ) ;
		Console.WriteLine ( "Elements of arr2: " ) ;
		foreach ( int i in arr2 )
			Console.Write ( i ) ;
	}
}
