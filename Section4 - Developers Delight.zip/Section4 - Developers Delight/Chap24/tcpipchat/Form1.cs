using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading ;
using System.Net ;
using System.Net.Sockets ;
using System.Text ;
using System.IO ;

namespace tcpipchat
{
	public class recvthread
	{
		Stream s ;
		ListBox l ;
		public recvthread ( Stream  ss, ListBox ll )
		{
			s = ss ;
			l = ll ;
		}
		public void read() 
		{
			Byte[] buf = new Byte[32] ;
			while ( true )
			{
				s.Read ( buf, 0, buf.Length ) ;
				String str = Encoding.ASCII.GetString ( buf ) ;
				l.Items.Add ( str ) ;
			}
		}
	}
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox sname;
		private System.Windows.Forms.TextBox port;

		private System.Windows.Forms.ListBox smessage;
		private System.Windows.Forms.TextBox message;
		private System.Windows.Forms.ListBox rmessage;
		private System.Windows.Forms.Button send;
		private System.Windows.Forms.GroupBox sentgroup;
		private System.Windows.Forms.GroupBox recdgroup;
		private System.Windows.Forms.GroupBox msggroup;
		private System.Windows.Forms.Label slabel;
		private System.Windows.Forms.Label pllabel;

		Stream st ;
		TcpClient tc ;
		private System.Windows.Forms.Button connects;
		private System.Windows.Forms.Button connectc;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose ( disposing ) ;

			if ( tc != null )
				tc.Close( ) ;
			if ( st != null )
				st.Close( ) ;
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.port = new System.Windows.Forms.TextBox();
			this.rmessage = new System.Windows.Forms.ListBox();
			this.recdgroup = new System.Windows.Forms.GroupBox();
			this.msggroup = new System.Windows.Forms.GroupBox();
			this.send = new System.Windows.Forms.Button();
			this.connectc = new System.Windows.Forms.Button();
			this.sentgroup = new System.Windows.Forms.GroupBox();
			this.message = new System.Windows.Forms.TextBox();
			this.sname = new System.Windows.Forms.TextBox();
			this.slabel = new System.Windows.Forms.Label();
			this.connects = new System.Windows.Forms.Button();
			this.smessage = new System.Windows.Forms.ListBox();
			this.pllabel = new System.Windows.Forms.Label();
			this.msggroup.SuspendLayout();
			this.SuspendLayout();
			// 
			// port
			// 
			this.port.Location = new System.Drawing.Point(88, 48);
			this.port.Name = "port";
			this.port.TabIndex = 3;
			this.port.Text = "";
			// 
			// rmessage
			// 
			this.rmessage.Location = new System.Drawing.Point(24, 272);
			this.rmessage.Name = "rmessage";
			this.rmessage.Size = new System.Drawing.Size(376, 69);
			this.rmessage.TabIndex = 7;
			// 
			// recdgroup
			// 
			this.recdgroup.Location = new System.Drawing.Point(16, 248);
			this.recdgroup.Name = "recdgroup";
			this.recdgroup.Size = new System.Drawing.Size(392, 104);
			this.recdgroup.TabIndex = 11;
			this.recdgroup.TabStop = false;
			this.recdgroup.Text = "Received";
			// 
			// msggroup
			// 
			this.msggroup.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.send});
			this.msggroup.Location = new System.Drawing.Point(16, 80);
			this.msggroup.Name = "msggroup";
			this.msggroup.Size = new System.Drawing.Size(392, 48);
			this.msggroup.TabIndex = 12;
			this.msggroup.TabStop = false;
			this.msggroup.Text = "Message";
			// 
			// send
			// 
			this.send.Location = new System.Drawing.Point(336, 16);
			this.send.Name = "send";
			this.send.Size = new System.Drawing.Size(48, 23);
			this.send.TabIndex = 6;
			this.send.Text = "Send";
			this.send.Click += new System.EventHandler(this.Send_Click);
			// 
			// connectc
			// 
			this.connectc.Location = new System.Drawing.Point(224, 48);
			this.connectc.Name = "connectc";
			this.connectc.Size = new System.Drawing.Size(120, 24);
			this.connectc.TabIndex = 2;
			this.connectc.Text = "Connect As Client";
			this.connectc.Click += new System.EventHandler(this.connectc_Click);
			// 
			// sentgroup
			// 
			this.sentgroup.Location = new System.Drawing.Point(16, 144);
			this.sentgroup.Name = "sentgroup";
			this.sentgroup.Size = new System.Drawing.Size(392, 96);
			this.sentgroup.TabIndex = 10;
			this.sentgroup.TabStop = false;
			this.sentgroup.Text = "Sent";
			// 
			// message
			// 
			this.message.Location = new System.Drawing.Point(24, 96);
			this.message.Name = "message";
			this.message.Size = new System.Drawing.Size(320, 20);
			this.message.TabIndex = 5;
			this.message.Text = "";
			// 
			// sname
			// 
			this.sname.Location = new System.Drawing.Point(88, 16);
			this.sname.Name = "sname";
			this.sname.Size = new System.Drawing.Size(120, 20);
			this.sname.TabIndex = 0;
			this.sname.Text = "";
			// 
			// slabel
			// 
			this.slabel.Location = new System.Drawing.Point(16, 18);
			this.slabel.Name = "slabel";
			this.slabel.Size = new System.Drawing.Size(72, 16);
			this.slabel.TabIndex = 8;
			this.slabel.Text = "Server Name";
			// 
			// connects
			// 
			this.connects.Location = new System.Drawing.Point(224, 16);
			this.connects.Name = "connects";
			this.connects.Size = new System.Drawing.Size(120, 24);
			this.connects.TabIndex = 2;
			this.connects.Text = "Connect As Server";
			this.connects.Click += new System.EventHandler(this.connects_Click);
			// 
			// smessage
			// 
			this.smessage.Location = new System.Drawing.Point(24, 160);
			this.smessage.Name = "smessage";
			this.smessage.Size = new System.Drawing.Size(376, 69);
			this.smessage.TabIndex = 4;
			// 
			// pllabel
			// 
			this.pllabel.Location = new System.Drawing.Point(56, 50);
			this.pllabel.Name = "pllabel";
			this.pllabel.Size = new System.Drawing.Size(32, 16);
			this.pllabel.TabIndex = 9;
			this.pllabel.Text = "Port";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 365);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pllabel,
																		  this.slabel,
																		  this.rmessage,
																		  this.message,
																		  this.smessage,
																		  this.port,
																		  this.connects,
																		  this.sname,
																		  this.sentgroup,
																		  this.recdgroup,
																		  this.msggroup,
																		  this.connectc});
			this.Name = "Form1";
			this.Text = "Chat";
			this.msggroup.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void connects_Click(object sender, System.EventArgs e)
		{
			int portno = Int32.Parse ( port.Text ) ;

			TcpListener l = new TcpListener ( portno ) ; 
			l.Start() ;
			tc = l.AcceptTcpClient() ;

			st = tc.GetStream() ;
			recvthread r = new recvthread ( st, rmessage ) ;
			Thread t = new Thread ( new ThreadStart ( r.read ) ) ;
			t.Start() ;
		}

		private void Send_Click(object sender, System.EventArgs e)
		{
			Byte[] buf = Encoding.ASCII.GetBytes ( message.Text ) ;
			st.Write ( buf, 0, buf.Length ) ;
			smessage.Items.Add ( message.Text ) ;
			message.Text = "" ;
		}

		private void connectc_Click(object sender, System.EventArgs e)
		{
			string servername = sname.Text ;
			int portno = Int32.Parse ( port.Text ) ;

			tc = new TcpClient();
			try
			{
				tc.Connect ( servername, portno ) ;
			}
			catch ( Exception e1 ) 
			{
				MessageBox.Show ( "Can not connet to server" ) ;
				return ;
			}

			st = tc.GetStream() ;
			recvthread r = new recvthread ( st, rmessage ) ;
			Thread t = new Thread ( new ThreadStart ( r.read ) ) ;
			t.Start() ;
		}
	}
}
