using System ;
namespace sample 
{
	enum color : byte
	{
		red, blue = 8, green
	}
	class Class1
	{
		static void Main ( string[ ] args )
		{
			Console.WriteLine ( color.green ) ;
		}
	}
}
