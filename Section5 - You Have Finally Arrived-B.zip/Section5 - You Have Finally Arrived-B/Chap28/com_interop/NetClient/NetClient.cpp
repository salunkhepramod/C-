// NetClient1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
# include "iostream.h"
# import "C:\dotnet\c#\book\Chapter28\com_interop\NetServer\bin\Debug\NetServer.tlb"
using namespace NetServer;
	
int _tmain(int argc, _TCHAR* argv[])
{
	CoInitialize ( NULL ) ;
	IMathPtr p ;
	HRESULT hr = p.CreateInstance ( "NetServer.Math" ) ;
	if ( FAILED ( hr ) )
	{
		cout<<"CreateInstance Failed"<<endl ;
		return 0;
	}
	cout<< p -> Add ( 10, 20 )<<endl ;
	cout<< p -> Sub ( 20, 10 )<<endl ;

	return 0;
}

