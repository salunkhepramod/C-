using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace udpchat
{
	/// <summary>
	/// Summary description for noteform.
	/// </summary>
	public class noteform : System.Windows.Forms.Form
	{
		private System.ComponentModel.Container components;
		private System.Windows.Forms.ContextMenu sendcontxt;
		private System.Windows.Forms.MenuItem pastemenu;
		private System.Windows.Forms.MenuItem delmenu;
		private System.Windows.Forms.MenuItem sendtomenu;
		private System.Windows.Forms.MenuItem copymenu;
		private System.Windows.Forms.MenuItem cutmenu;
		public System.Windows.Forms.TextBox messagebox;
		private string mystr ;
		private sendform mysendf;
		public string MyStr
		{
			get
			{
				return mystr ;	
			}
			set
			{
				mystr = value ;
			}
		}
		/// <summary>
		/// Required designer variable.
		/// </summary>
		

		public noteform()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			 mysendf  = new sendform() ;
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pastemenu = new System.Windows.Forms.MenuItem();
			this.sendtomenu = new System.Windows.Forms.MenuItem();
			this.delmenu = new System.Windows.Forms.MenuItem();
			this.cutmenu = new System.Windows.Forms.MenuItem();
			this.sendcontxt = new System.Windows.Forms.ContextMenu();
			this.copymenu = new System.Windows.Forms.MenuItem();
			this.messagebox = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// pastemenu
			// 
			this.pastemenu.Index = 3;
			this.pastemenu.Text = "Paste";
			this.pastemenu.Click += new System.EventHandler(this.pastemenu_Click);
			// 
			// sendtomenu
			// 
			this.sendtomenu.Index = 0;
			this.sendtomenu.Text = "Send To";
			this.sendtomenu.Click += new System.EventHandler(this.sendtomenu_Click);
			// 
			// delmenu
			// 
			this.delmenu.Index = 4;
			this.delmenu.Text = "Delete";
			this.delmenu.Click += new System.EventHandler(this.delmenu_Click);
			// 
			// cutmenu
			// 
			this.cutmenu.Index = 2;
			this.cutmenu.Text = "Cut";
			this.cutmenu.Click += new System.EventHandler(this.cutmenu_Click);
			// 
			// sendcontxt
			// 
			this.sendcontxt.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.sendtomenu,
																					   this.copymenu,
																					   this.cutmenu,
																					   this.pastemenu,
																					   this.delmenu});
			this.sendcontxt.Popup += new System.EventHandler(this.sendcontxt_Popup);
			// 
			// copymenu
			// 
			this.copymenu.Index = 1;
			this.copymenu.Text = "Copy";
			this.copymenu.Click += new System.EventHandler(this.copymenu_Click);
			// 
			// messagebox
			// 
			this.messagebox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(128)), ((System.Byte)(255)), ((System.Byte)(128)));
			this.messagebox.ContextMenu = this.sendcontxt;
			this.messagebox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.messagebox.Multiline = true;
			this.messagebox.Name = "messagebox";
			this.messagebox.Size = new System.Drawing.Size(216, 139);
			this.messagebox.TabIndex = 0;
			this.messagebox.Text = "";
			// 
			// noteform
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(128)), ((System.Byte)(255)), ((System.Byte)(128)));
			this.ClientSize = new System.Drawing.Size(216, 139);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.messagebox});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "noteform";
			this.ResumeLayout(false);

		}
		#endregion

		private void sendtomenu_Click(object sender, System.EventArgs e)
		{
			mysendf.settextbox ( MyStr ) ;
			mysendf.ShowDialog();
		}

		private void sendcontxt_Popup(object sender, System.EventArgs e)
		{
			sendtomenu.Text = "Send to " + this.MyStr;
		}

		private void copymenu_Click(object sender, System.EventArgs e)
		{
			messagebox.Copy( ) ;
		}

		private void cutmenu_Click(object sender, System.EventArgs e)
		{
			messagebox.Cut( ) ;
		}

		private void pastemenu_Click(object sender, System.EventArgs e)
		{
			messagebox.Paste( ) ;
		}

		private void delmenu_Click(object sender, System.EventArgs e)
		{
			this.Close( ) ;
		}

		
	}
}
