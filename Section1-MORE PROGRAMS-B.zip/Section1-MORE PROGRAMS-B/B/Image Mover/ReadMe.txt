The 'imagemover' is a simple WinForm application. This program demonstrates how to handle the evets that occur on pressing the navigation keys like Up-Arrow, Down-Arrow, 
Right-Arrow, Left-Arrow, Home etc. 

On executing this application a window would get displayed with two colored images in the client area. Place the mouse on any one of the images and press the arrow keys to move the image within the client area.