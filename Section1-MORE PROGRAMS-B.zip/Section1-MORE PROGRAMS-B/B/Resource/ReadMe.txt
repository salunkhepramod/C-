1] resource

This is a console application in which we have created a resource file.

To this resource file we have added some strings and a '.jpg' image.

2] resourceclient

This program uses the resource file that we have created in 'resource' program.

It reads the resource file and displays the strings and the image stored in it in a Window.

On executing this program, a window would get displayed. You will find the strings that we have added in the resource file, displayed in the appropriate textboxes. The image would also 
get displayed in a picture box.
