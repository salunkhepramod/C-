namespace Simple
{
	using System ;
	class Class1
	{
		static void Main ( string[ ] args )
		{
			for ( int i = 0 ; i < args.Length ; i++ )
				Console.WriteLine ( args [ i ] ) ;
		}
	}
}
