using System;
namespace sample
{
	class Class1
	{
		static void Main ( string[ ] args )
		{
			string s1 = "Good Morning" ;
			string s2 ;
			s2 = s1 ;
			s1 = "Wake Up" ;
			Console.WriteLine ( s1 ) ;
			Console.WriteLine ( s2 ) ;
			
		}
	}
}
