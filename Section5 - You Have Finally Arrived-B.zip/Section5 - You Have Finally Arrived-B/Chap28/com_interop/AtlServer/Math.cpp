// Math.cpp : Implementation of CMath

#include "stdafx.h"
#include "Math.h"


// CMath


STDMETHODIMP CMath::Add(int n1, int n2, int * n3)
{
	*n3 = n1 + n2 ;
	return S_OK;
}

STDMETHODIMP CMath::Sub(int n1, int n2, int * n3)
{
	*n3 = n1 - n2 ;

	return S_OK;
}
