using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DeleteFileDlg
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Form2 : System.Windows.Forms.Form
	{
		public System.Windows.Forms.Label Label;
		public System.Windows.Forms.TextBox TextBox;
		public System.Windows.Forms.Button Cancel;
		public System.Windows.Forms.Button Search;
		public System.Windows.Forms.Button Delete;
		public OpenFileDialog od ;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Cancel = new System.Windows.Forms.Button();
			this.Search = new System.Windows.Forms.Button();
			this.Delete = new System.Windows.Forms.Button();
			this.TextBox = new System.Windows.Forms.TextBox();
			this.Label = new System.Windows.Forms.Label();
			this.SuspendLayout();
			od = new OpenFileDialog ( ) ;
			// 
			// Cancel
			// 
			this.Cancel.Location = new System.Drawing.Point(120, 72);
			this.Cancel.Name = "Cancel";
			this.Cancel.Size = new System.Drawing.Size(72, 24);
			this.Cancel.TabIndex = 2;
			this.Cancel.Text = "&Cancel";
			this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
			// 
			// Search
			// 
			this.Search.Location = new System.Drawing.Point(216, 72);
			this.Search.Name = "Search";
			this.Search.Size = new System.Drawing.Size(72, 24);
			this.Search.TabIndex = 2;
			this.Search.Text = "&Search";
			this.Search.Click += new System.EventHandler(this.Search_Click);
			// 
			// Delete
			// 
			this.Delete.Location = new System.Drawing.Point(24, 72);
			this.Delete.Name = "Delete";
			this.Delete.Size = new System.Drawing.Size(72, 24);
			this.Delete.TabIndex = 2;
			this.Delete.Text = "&Delete";
			this.Delete.Click += new System.EventHandler(this.Delete_Click);
			// 
			// TextBox
			// 
			this.TextBox.Location = new System.Drawing.Point(64, 24);
			this.TextBox.Name = "TextBox";
			this.TextBox.Size = new System.Drawing.Size(168, 20);
			this.TextBox.TabIndex = 1;
			this.TextBox.Text = "FileName";
			// 
			// Label
			// 
			this.Label.Location = new System.Drawing.Point(16, 32);
			this.Label.Name = "Label";
			this.Label.Size = new System.Drawing.Size(40, 16);
			this.Label.TabIndex = 0;
			this.Label.Text = "File :";
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(328, 118);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Search,
																		  this.Cancel,
																		  this.Delete,
																		  this.TextBox,
																		  this.Label});
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form2";
			this.Text = "Delete File";
			this.ResumeLayout(false);

		}
		#endregion

		private void Delete_Click(object sender, System.EventArgs e)
		{
			String s = TextBox.Text ;
			FileInfo file = new FileInfo ( s ) ;
			try
			{
				file.Delete ( ) ;
				MessageBox.Show ( "File Deleted" ) ;
			}
			catch ( Exception ex)
			{
				MessageBox.Show ( "Unable to delete file" ) ;
			}
		}

		private void Cancel_Click(object sender, System.EventArgs e)
		{
			Close ( ) ;
		}

		private void Search_Click(object sender, System.EventArgs e)
		{
			od.ShowDialog ( ) ;			 
			TextBox.Text = od.FileName; 
		}
	}
}
