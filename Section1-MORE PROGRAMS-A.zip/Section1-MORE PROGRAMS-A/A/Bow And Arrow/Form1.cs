using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading ;

namespace Bowandarrow
{
	class balloon
	{
		public int x1, y1, x2, y2 ;
		public int balloonstatus ;
		public Image balloonimg ;
		public Image balloonbgimg ;
		public Image burstballoonimg ;
	}
	class arrow
	{
		public int x1, y1, x2, y2 ;
		public int arrowstatus ;
		public Image arrowimg ; 
		public Image arrowbgimg ;
	}
	class arrowthread 
	{
		Form f = new Form( ) ;
		arrow a = new arrow( ) ;
		balloon[] b = new balloon[10] ;
		int i ;
		public arrowthread ( arrow aa, Form ff , int an, balloon[] bb ) 
		{
			f = ff ;
			a = aa ;
			i = an ;
			b = bb ; 
		}
		public void threadfunc( )
		{
			while ( true )
			{
				if ( a.arrowstatus == 1 ) //Alive
				{
					Graphics g = f.CreateGraphics( ) ;
					g.DrawImage ( a.arrowbgimg, a.x1, a.y1 ) ;
					g.DrawImage ( a.arrowimg, a.x1+20, a.y1 ) ;       
					a.x1 = a.x1 + 20 ; 
					a.x2 = a.x2 + 20 ;
					if ( a.x1 > 670 )
					{
						a.arrowstatus = 0 ;//dead
						break ;
					}
				}
				Random rand = new Random( ) ;
				int no = rand.Next ( 50000 ) % 100 ;
				Thread.Sleep ( no ) ;
				int j ;
				for (  j = 0 ; j <= 9 ; j++ )
				{
					if ( b[ j ].balloonstatus == 1 )
					{
					
						if ( a.x2 >= b[ j ].x1 && a.x2 <= b[ j ].x2 
							&& a.y1 + 4 >= b[ j ].y1 && a.y1 + 4 <= b[ j ].y2 )
						{
							b[ j ].balloonstatus = 2 ;
						}
					}
				}	 
			}
		}
	}
	class balloonthread
	{
		int i ;
		Form ff ;
		balloon b = new balloon( ) ;
		public balloonthread ( balloon bb, Form f, int bn )
		{
			ff = f ;
			i = bn ;
			b = bb ;
		}
		public void threadfunc( )
		{
			Thread.Sleep ( 100 ) ;
			while ( true )
			{
				Graphics g = ff.CreateGraphics( ) ;
				if ( b.balloonstatus == 1 ) //up
				{
					g.DrawImage ( b.balloonbgimg, b.x1, b.y1+5 ) ;
					g.DrawImage ( b.balloonimg, b.x1, b.y1 ) ;
					b.y1 = b.y1 - 5 ;
					b.y2 = b.y2 - 5 ;
					if ( b.y1 < -50 )
						b.balloonstatus = 0 ;
				}
				if ( b.balloonstatus == 2 ) //down
				{
					g.DrawImage ( b.balloonbgimg, b.x1, b.y1-5 ) ;
					g.DrawImage ( b.burstballoonimg, b.x1, b.y1 ) ;
					b.y1 = b.y1 + 5 ;
					b.y2 = b.y2 + 5 ;
					if ( b.y1 > 500 )
						b.balloonstatus = 0 ;
				}
				if ( b.balloonstatus == 0 ) //no where
				{
					b.x1 = 300 + i * 30 ;	
					b.y1 = 410 ;
					b.x2 = b.x1 + 30 ;
					b.y2 = b.y1 + 50 ;
					b.balloonstatus = 1 ;
				}
				Random rand = new Random( ) ;
				int no = rand.Next ( 5000 ) % 300 ;
				Thread.Sleep( no ) ;
			}
		}
	}

	public class Form1 : System.Windows.Forms.Form
	{
		balloonthread[] bth = new balloonthread[10] ;
		arrowthread[] arth = new arrowthread[10] ;
		Image[] person = new Image[3] ;
		balloon[] b = new balloon[10] ;
		arrow[] a = new arrow[10] ;
		int arrownumber = 0 ;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			String s ; 
			int i ;
			for (  i = 1 ; i <= 3 ; i++ )
			{
				s = "image" + i + ".gif" ;
				person[i-1] = Image.FromFile ( s ) ;
			}
	    
			for (  i = 0 ; i <= 9 ; i++ )
			{
				b[i] = new balloon() ;
				b[i].x1 = 300 + i * 30 ;
				b[i].y1 = 460 ;
				b[i].x2 = b[i].x1 + 30 ;
				b[i].y2 = b[i].y1 + 50 ;
				b[i].balloonstatus = 1  ;
				s = "image" + ( i + 4 ) + ".gif" ;
				b[i].balloonimg = Image.FromFile ( s ) ;
				b[i].balloonbgimg = Image.FromFile ( "image14.gif" ) ;
				s = "image" + ( i + 17 ) + ".gif" ;
				b[i].burstballoonimg = Image.FromFile ( s ) ;
			}

    		for( i = 0 ; i <= 9 ; i++ )
			{
				a[i] = new arrow() ;
				a[i].x1 = 120 ;
				a[i].y1 = 85 ;
				a[i].x2 = a[i].x1 + 80 ;
				a[i].y2 = a[i].y1 + 10 ;
				a[i].arrowstatus = 0 ;
				a[i].arrowimg = Image.FromFile ( "image15.gif" ) ;
				a[i].arrowbgimg = Image.FromFile ( "image16.gif" ) ;
			}

        	for (  i = 0 ; i <= 9 ; i++ )
			{
				bth[i] = new balloonthread ( b[i], this, i ) ;
				Thread t1 = new Thread ( new ThreadStart ( bth[i].threadfunc ) ) ;
				t1.Start( ) ;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(648, 405);
			this.Name = "Form1";
			this.Text = "Bow and Arrow";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
			this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g = e.Graphics ;
			Size r = ClientSize ;
			SolidBrush b = new SolidBrush ( Color.FromArgb ( 0, 128, 0 ) ) ;
			g.FillRectangle ( b, 0, 0, r.Width, r.Height ) ;
			g.DrawImage ( person[0], 10, 25 ) ;
		}

		private void Form1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if ( arrownumber == 10 )
				return ;
			Graphics g = CreateGraphics( ) ;
			g.DrawImage ( person[2], 10, 25 ) ;	 
			a [ arrownumber ].arrowstatus = 1 ;//alive
			arth [ arrownumber ] = new arrowthread ( a[arrownumber], this, arrownumber, b ) ;
			Thread t = new Thread( new ThreadStart ( arth [ arrownumber ].threadfunc ) ) ;
			t.Start() ;
			arrownumber++ ;
		}

		private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			Graphics g = CreateGraphics( ) ;
			g.DrawImage ( person[1], 10, 25 ) ;	
		}
	}
}
