using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml ;

namespace mylist
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm2 : System.Web.UI.Page
	{
		ArrayList a1 = new ArrayList() ;		
		ArrayList a2 = new ArrayList() ;
		protected System.Web.UI.WebControls.DataList Datalist2;
		protected System.Web.UI.WebControls.DataList DataList1;
		protected System.Web.UI.HtmlControls.HtmlForm Form2;
		protected System.Web.UI.WebControls.HyperLink Hyperlink2;		
		int count ;
		public void DisplayTree(XmlNode node)
		{
			if (node.HasChildNodes)
			{
				if ( node.Name == "reply" )
					count++ ;

				node = node.FirstChild;
				while (node != null)
				{
					DisplayTree(node);
					node = node.NextSibling;
				}
			}
			else
			{
				a1.Add(node.ParentNode.Name) ;
				a2.Add(node.Value);
			}
		}
		public WebForm2()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}
		ICollection CreateDataSource2() 
		{
			DataTable dt = new DataTable();
			DataRow dr;
			
			dt.Columns.Add(new DataColumn("Name", typeof(string)));
			dt.Columns.Add(new DataColumn("Date", typeof(DateTime)));
			dt.Columns.Add(new DataColumn("Mail", typeof(string)));
			dt.Columns.Add(new DataColumn("Answer", typeof(string)));

			for (int i = 5; i < 5+4*count; ) 
			{
				dr = dt.NewRow();
				dr[0] = a2[i++];
				dr[1] = a2[i++];
				dr[2] = a2[i++];
				dr[3] = a2[i++];
				dt.Rows.Add(dr);
			}

			DataView dv = new DataView(dt);
			return dv;
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			string id = Request.QueryString["id"] ;
			string path = MapPath("csharp") ;
			string file = path + "\\csharp" + id + ".xml" ; 
			XmlDocument myXmlDocument = new XmlDocument();
			myXmlDocument.Load(file);
			
			DisplayTree(myXmlDocument.DocumentElement);

			DataTable dt = new DataTable();
			DataRow dr;

			dt.Columns.Add(new DataColumn("Question", typeof(string)));
			dt.Columns.Add(new DataColumn("Name", typeof(string)));
			dt.Columns.Add(new DataColumn("Mail", typeof(string)));

			dr = dt.NewRow();
			dr[0] = a2[1] ;
			dr[1] = a2[2] ;
			dr[2] = a2[4] ;
			dt.Rows.Add(dr);

			DataView dv = new DataView(dt);
			DataList1.DataSource = dv ;
			DataList1.DataBind() ;

			Datalist2.DataSource =CreateDataSource2();
			Datalist2.DataBind();
			Session["id"] = id ;
			Session["topic"] = "csharp" ;
			
			//}
		}
		
		private void Page_Init(object sender, EventArgs e)
		{
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Datalist2.ItemCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.Datalist2_ItemCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Datalist2_ItemCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
		{
			string cmd = ((LinkButton)e.CommandSource).CommandName;
			if (cmd == "select")
				Datalist2.SelectedIndex = e.Item.ItemIndex;
			Datalist2.DataBind();
		}
		
	}
}
