// McppServer.h

#pragma once

using namespace System;

namespace McppServer
{
	public __gc class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
