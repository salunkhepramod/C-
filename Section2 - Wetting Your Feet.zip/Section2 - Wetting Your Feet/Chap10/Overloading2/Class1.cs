using System; 
namespace Convert
{
	class complex
	{
		int real, imag ;
	
		public complex ( int r )
		{
			real = r ;
			imag = 0 ;
		}

		public static implicit operator complex ( int s )
		{
			return new complex ( s ) ;
		}

		public static explicit operator int ( complex s )
		{
			return s.real ;
		}

		public void showdata( )
		{
			Console.WriteLine ( real + " " + imag + "i" ) ;
		}
	}

	class Class1
	{
		static void Main ( string[ ] args )
		{
			complex c1 ;
			c1 = 10 ;
			c1.showdata( ) ;

			int i = ( int ) c1 ;
			Console.WriteLine ( "Value of i: " + i )  ;

		}
	}
}
