using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TranformationDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(504, 273);
			this.Name = "Form1";
			this.Text = "Tranformation";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics  g = e.Graphics ;
			Font  myfont = new  Font ( "Times New Roman", 100 ) ;

			Matrix  mymat = new  Matrix( ) ;
			mymat.Shear ( -1.4f, 0f ) ;
			mymat.Scale ( 1, 0.5f ) ;
			mymat.Translate ( 236, 170 ) ;

			g.Transform = mymat ;

			SolidBrush  mybrush = new  SolidBrush ( Color.Gray ) ;
			g.DrawString ( "K", myfont, mybrush, 50, 50 ) ;
			g.DrawString ( "I", myfont, mybrush, 150, 50 ) ;
			g.DrawString ( "C", myfont, mybrush, 200, 50 ) ;
			g.DrawString ( "I", myfont, mybrush, 300, 50 ) ;
			g.DrawString ( "T", myfont, mybrush, 350, 50 ) ;
			g.ResetTransform ( ) ;

			mybrush.Color = Color.DarkMagenta ;
			g.DrawString ( "K", myfont, mybrush, 50, 50 ) ;

			mybrush.Color = Color.FromArgb ( 150, 0, 255, 255 ) ;
			g.DrawString ( "I", myfont, mybrush, 150, 50 ) ;

			LinearGradientBrush  lgb = new  LinearGradientBrush ( new Point ( 200, 50 ), new Point ( 350, 200 ), 
				Color.Brown, Color.Yellow ) ;
			g.DrawString ( "C", myfont, lgb, 200, 50 ) ;

			HatchBrush  hb = new  HatchBrush ( HatchStyle.DiagonalCross, Color.Blue, Color.Red ) ;
			g.DrawString ( "I", myfont, hb, 300, 50 ) ;

			Image  myimg = Image.FromFile ( "test.bmp" ) ;
			TextureBrush tb = new TextureBrush ( myimg ) ;
			g.DrawString ( "T", myfont, tb, 350, 50 ) ;

		}
	}
}
