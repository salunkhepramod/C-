#include "stdafx.h"
using namespace System;

namespace McppServer
{
	public __gc class fact
	{
		public:
			int factorial ( int n )
			{
				int j = n ;
				for ( int i = 1 ; i < n ; i++ )
					j = j * i ;
				return j ;
			}
	};
}
