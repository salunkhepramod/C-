using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Imgmov
{
	class bounds
	{
		public Rectangle r ;
	} ;

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{

		Image img1, img2, img3 ;
		int imgno ;
		bounds b1 = new bounds() ;
		bounds b2 = new bounds() ;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		/// 

		private System.ComponentModel.Container components = null;

		public Form1()
		{
			imgno = 0 ;
			b1.r = new Rectangle(100,100,70,70) ;
			b2.r = new Rectangle(200,100,70,70) ;
			
			img1 = Image.FromFile ( "img1.gif" ) ;
			img2 = Image.FromFile ( "img2.gif" ) ;
			img3 = Image.FromFile ( "img3.gif" ) ;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(397, 278);
			this.Name = "Form1";
			this.Text = "Image Move";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g = e.Graphics ;
			g.DrawImage ( img1, b1.r.X, b1.r.Y ) ;
			g.DrawImage ( img2, b2.r.X, b2.r.Y ) ;
		}

		private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			Point pt = new Point();
			pt.X = e.X ;
			pt.Y = e.Y ;
//			MessageBox.Show ( pt.ToString()) ;

			if ( b1.r.Contains ( pt ) )
				imgno = 1 ;
			
			if ( b2.r.Contains ( pt ) )
				imgno = 2 ;
           
		}

		
		private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			Image img ; 
			bounds b3 = new bounds() ;
			Graphics g = CreateGraphics( ) ;

			if ( imgno == 0 )
				return ;
			if ( imgno == 1 )
			{
				img = img1 ;
				b3 = b1 ;
				g.DrawImage ( img3, b3.r.X , b3.r.Y ) ;        
				if ( b2.r.Contains ( b3.r.X, b3.r.Y ) || b2.r.Contains ( b3.r.X + 70, b3.r.Y )|| b2.r.Contains ( b3.r.X , b3.r.Y+70 )|| b2.r.Contains ( b3.r.X + 70, b3.r.Y+70 ) )
					g.DrawImage ( img2, b2.r.X , b2.r.Y ) ;   
			}
			else
			{
				img = img2 ;
				b3 = b2 ;
				g.DrawImage ( img3, b3.r.X , b3.r.Y ) ;        
				if ( b1.r.Contains ( b3.r.X, b3.r.Y ) || b1.r.Contains ( b3.r.X + 70, b3.r.Y )|| b1.r.Contains ( b3.r.X , b3.r.Y+70 )|| b1.r.Contains ( b3.r.X + 70, b3.r.Y + 70 ) )
					g.DrawImage ( img1, b1.r.X , b1.r.Y ) ;  
			}

			switch ( e.KeyCode )
			{
				case Keys.Down:
					b3.r.Y += 5 ;
					break ;
				case Keys.Up:
					b3.r.Y -= 5 ;
					break ;
				case Keys.Right:
					b3.r.X += 5 ;
					break ;
				case Keys.Left:
					b3.r.X -= 5 ;
					break ;
				case Keys.PageUp:
					b3.r.Y = 5 ;
					break ;
				case Keys.PageDown:
					b3.r.Y = Height - 70 ;
					break ;
				case Keys.Home:
					b3.r.X = 0 ;
					break ;
				case Keys.End:
					b3.r.X = Width - 70 ;
					break ;
				case Keys.F1:
					MessageBox.Show ( "Help u r self" ) ;
					break ;
			}
			g.DrawImage ( img, b3.r.X , b3.r.Y ) ;
		}

	}
}
