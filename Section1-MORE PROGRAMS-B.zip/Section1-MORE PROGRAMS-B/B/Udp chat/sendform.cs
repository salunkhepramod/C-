using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net ;
using System.Net.Sockets ;

namespace udpchat
{
	/// <summary>
	/// Summary description for sendform.
	/// </summary>
	public class sendform : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox message;
		private System.Windows.Forms.TextBox pcname;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button sendbut;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		public string msg;
		private UdpClient client;

		public sendform()
		{
			InitializeComponent();
			client = new UdpClient( ) ; 
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
			client.Close();
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.sendbut = new System.Windows.Forms.Button();
			this.pcname = new System.Windows.Forms.TextBox();
			this.message = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Message";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 72);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Send To:";
			// 
			// sendbut
			// 
			this.sendbut.Location = new System.Drawing.Point(224, 72);
			this.sendbut.Name = "sendbut";
			this.sendbut.TabIndex = 2;
			this.sendbut.Text = "Send";
			this.sendbut.Click += new System.EventHandler(this.sendbut_Click);
			// 
			// pcname
			// 
			this.pcname.Location = new System.Drawing.Point(80, 72);
			this.pcname.Name = "pcname";
			this.pcname.Size = new System.Drawing.Size(128, 20);
			this.pcname.TabIndex = 1;
			this.pcname.Text = "";
			// 
			// message
			// 
			this.message.Location = new System.Drawing.Point(80, 32);
			this.message.Name = "message";
			this.message.Size = new System.Drawing.Size(216, 20);
			this.message.TabIndex = 0;
			this.message.Text = "";
			// 
			// sendform
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(320, 125);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label2,
																		  this.label1,
																		  this.sendbut,
																		  this.pcname,
																		  this.message});
			this.Name = "sendform";
			this.Text = "sendform";
			this.ResumeLayout(false);

		}
		#endregion

		private void sendbut_Click(object sender, System.EventArgs e)
		{
			msg = message.Text;
			msg = msg + "@" + Dns.GetHostName() ;

			System.Text.ASCIIEncoding encode = new System.Text.ASCIIEncoding();
			byte[] sendData = encode.GetBytes(msg);
			string sendname = pcname.Text ;
			try
			{
				//client.Send(sendData,sendData.Length,sendname,200 ) ;
				client.Send ( sendData, sendData.Length, sendname, 200 ) ;
				this.Close();
			}
			catch ( Exception )
			{
				MessageBox.Show ( "Cann't send to " + sendname ) ;
			}
		}
		public void settextbox(string sendstr)
		{
			pcname.Text = sendstr;
		}
		public string getmsg()
		{
			return msg;
		}
	}
	}

