using System ;
using System.Collections ;

namespace collect
{
	class Class1
	{
		static void Main(string[] args)
		{
			Stack st = new Stack( ) ;

			st.Push ( 10 ) ;
			st.Push ( 11 ) ;
			st.Push ( 12 ) ;
			st.Push ( 13 ) ;

			Console.WriteLine ( "Element popped: {0}", st.Pop( ) ) ;

			IEnumerator e = st.GetEnumerator ( ) ;
			while ( e.MoveNext( ) )
				Console.WriteLine ( e.Current ) ;
		}
	}
}
