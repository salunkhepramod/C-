using System;
using System.Resources ;
using System.Drawing ;
namespace resourse1
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
			ResourceWriter r = new ResourceWriter("Demo.resources") ;
			using ( Image img = Image.FromFile ( "letusc.jpg") ) 
			{
				r.AddResource("logo", img) ;
				r.AddResource("Title", "Let Us C" );
				r.AddResource("Author", "Yashavant Kanetkar" );
				r.AddResource("Subject", "C Programming" );
				r.AddResource("Pages", "772" );
				r.AddResource("Publisher", "BPB" );
				r.AddResource("Category", "Intermediate" );
				r.Close() ;
			}
		}

	}
	
}
