using System ;
namespace sample
{
	class Class1
	{
		static void Main ( string[ ] args )
		{
			Console.WriteLine ( "Enter an integer: " ) ;
			string s = Console.ReadLine( ) ;
			int i = int.Parse ( s ) ;

			Console.WriteLine ( "Enter a float: " ) ;
			s = Console.ReadLine( ) ;
			float f = float.Parse ( s ) ;

			float t = f + i ;
			Console.WriteLine ( t ) ;
		}
	}
}
