using System ;
namespace sample
{
	struct mystruct
	{
		public int i ;
	}

	class Class1
	{
		static void Main ( string[ ] args )
		{
			mystruct x = new mystruct( ) ;
			x.i = 9 ;

			mystruct y ;
			y = x ;

			y.i = 5 ;

			Console.WriteLine ( x.i ) ;
			Console.WriteLine ( y.i ) ;
		}
	}
}
