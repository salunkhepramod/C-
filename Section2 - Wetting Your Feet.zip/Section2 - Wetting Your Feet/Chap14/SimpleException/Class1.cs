using System;
namespace Sample
{
	class Class1
	{
		static void Main ( string [ ] args )
		{
			int a, b = 0 ;
			try
			{
				a = 10 / b ;
			}
			catch ( DivideByZeroException e )
			{
				Console.WriteLine ( e ) ;
			}
			Console.WriteLine ( "Remaining program" ) ;
		}
	}
}
