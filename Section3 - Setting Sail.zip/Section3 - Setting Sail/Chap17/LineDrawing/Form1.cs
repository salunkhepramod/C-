using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LineDrawing
{
	public class Form1 : System.Windows.Forms.Form
	{
		private int r = 255, g = 0, b = 0 ;
		private Color c ;
		private Pen mypen ;
		private Graphics gr ;

		private System.Windows.Forms.ContextMenu style;
		private System.Windows.Forms.MainMenu mymenu ;
		private System.Windows.Forms.MenuItem shapemenu ;
		private System.Windows.Forms.MenuItem colormenu ;

		private System.Windows.Forms.MenuItem linemenu ;
		private System.Windows.Forms.MenuItem rectmenu ;
		private System.Windows.Forms.MenuItem ellipsemenu ;
		
		
		private System.Windows.Forms.ToolBar mytoolbar ;
		private System.Windows.Forms.ToolBarButton linebut ;
		private System.Windows.Forms.ToolBarButton rectbut ;
		private System.Windows.Forms.ToolBarButton ellipsebut ;

		private System.Windows.Forms.ToolBarButton bluebut ;
		private System.Windows.Forms.ToolBarButton redbut ;
		private System.Windows.Forms.ToolBarButton greenbut ;

		private System.Windows.Forms.ImageList imglist ;
		private System.Windows.Forms.MenuItem dot;
		private System.Windows.Forms.MenuItem dash;
		private System.Windows.Forms.MenuItem dashdot;
		private System.Windows.Forms.MenuItem soild;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel shape;
		private System.Windows.Forms.MenuItem redmenu;
		private System.Windows.Forms.MenuItem bluemenu;
		private System.Windows.Forms.ToolBarButton seperator;
		private System.Windows.Forms.MenuItem greenmenu;

		private System.ComponentModel.IContainer components ; 

		public Form1()
		{
			c = Color.FromArgb ( r, g, b ) ;
			mypen = new Pen ( c, 3 ) ;
			gr = CreateGraphics() ;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose ( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose( ) ;
				}
			}
			base.Dispose( disposing );
		}

  		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.greenmenu = new System.Windows.Forms.MenuItem();
			this.bluebut = new System.Windows.Forms.ToolBarButton();
			this.dot = new System.Windows.Forms.MenuItem();
			this.ellipsemenu = new System.Windows.Forms.MenuItem();
			this.imglist = new System.Windows.Forms.ImageList(this.components);
			this.redmenu = new System.Windows.Forms.MenuItem();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.shape = new System.Windows.Forms.StatusBarPanel();
			this.linemenu = new System.Windows.Forms.MenuItem();
			this.ellipsebut = new System.Windows.Forms.ToolBarButton();
			this.colormenu = new System.Windows.Forms.MenuItem();
			this.bluemenu = new System.Windows.Forms.MenuItem();
			this.redbut = new System.Windows.Forms.ToolBarButton();
			this.greenbut = new System.Windows.Forms.ToolBarButton();
			this.soild = new System.Windows.Forms.MenuItem();
			this.dashdot = new System.Windows.Forms.MenuItem();
			this.mytoolbar = new System.Windows.Forms.ToolBar();
			this.linebut = new System.Windows.Forms.ToolBarButton();
			this.rectbut = new System.Windows.Forms.ToolBarButton();
			this.seperator = new System.Windows.Forms.ToolBarButton();
			this.rectmenu = new System.Windows.Forms.MenuItem();
			this.dash = new System.Windows.Forms.MenuItem();
			this.style = new System.Windows.Forms.ContextMenu();
			this.shapemenu = new System.Windows.Forms.MenuItem();
			this.mymenu = new System.Windows.Forms.MainMenu();
			((System.ComponentModel.ISupportInitialize)(this.shape)).BeginInit();
			this.SuspendLayout();
			// 
			// greenmenu
			// 
			this.greenmenu.Index = 2;
			this.greenmenu.Text = "&Green";
			this.greenmenu.Click += new System.EventHandler(this.gmenu_Click);
			// 
			// bluebut
			// 
			this.bluebut.ImageIndex = 5;
			this.bluebut.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.bluebut.ToolTipText = "Blue";
			// 
			// dot
			// 
			this.dot.Index = 1;
			this.dot.Text = "Dot";
			this.dot.Click += new System.EventHandler(this.dot_Click);
			// 
			// ellipsemenu
			// 
			this.ellipsemenu.Index = 2;
			this.ellipsemenu.Text = "&Ellipse";
			this.ellipsemenu.Click += new System.EventHandler(this.ellipsemenu_Click);
			// 
			// imglist
			// 
			this.imglist.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imglist.ImageSize = new System.Drawing.Size(16, 16);
			this.imglist.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist.ImageStream")));
			this.imglist.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// redmenu
			// 
			this.redmenu.Checked = true;
			this.redmenu.Index = 0;
			this.redmenu.Text = "&Red";
			this.redmenu.Click += new System.EventHandler(this.rmenu_Click);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 253);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.shape});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(360, 20);
			this.statusBar1.TabIndex = 1;
			// 
			// shape
			// 
			this.shape.ToolTipText = "Shape";
			this.shape.Width = 300;
			// 
			// linemenu
			// 
			this.linemenu.Index = 0;
			this.linemenu.Text = "&Line";
			this.linemenu.Click += new System.EventHandler(this.linemenu_Click);
			// 
			// ellipsebut
			// 
			this.ellipsebut.ImageIndex = 2;
			this.ellipsebut.ToolTipText = "Ellipse";
			// 
			// colormenu
			// 
			this.colormenu.Index = 1;
			this.colormenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.redmenu,
																					  this.bluemenu,
																					  this.greenmenu});
			this.colormenu.Text = "Colors";
			// 
			// bluemenu
			// 
			this.bluemenu.Index = 1;
			this.bluemenu.Text = "&Blue";
			this.bluemenu.Click += new System.EventHandler(this.bmenu_Click);
			// 
			// redbut
			// 
			this.redbut.ImageIndex = 3;
			this.redbut.Pushed = true;
			this.redbut.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.redbut.ToolTipText = "Red";
			// 
			// greenbut
			// 
			this.greenbut.ImageIndex = 4;
			this.greenbut.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.greenbut.ToolTipText = "Green";
			// 
			// soild
			// 
			this.soild.Index = 0;
			this.soild.Text = "Solid";
			this.soild.Click += new System.EventHandler(this.solid_Click);
			// 
			// dashdot
			// 
			this.dashdot.Index = 3;
			this.dashdot.Text = "Dash Dot";
			this.dashdot.Click += new System.EventHandler(this.dashdot_Click);
			// 
			// mytoolbar
			// 
			this.mytoolbar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						 this.linebut,
																						 this.rectbut,
																						 this.ellipsebut,
																						 this.seperator,
																						 this.redbut,
																						 this.greenbut,
																						 this.bluebut});
			this.mytoolbar.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mytoolbar.DropDownArrows = true;
			this.mytoolbar.ImageList = this.imglist;
			this.mytoolbar.Name = "mytoolbar";
			this.mytoolbar.ShowToolTips = true;
			this.mytoolbar.Size = new System.Drawing.Size(360, 25);
			this.mytoolbar.TabIndex = 0;
			this.mytoolbar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.mytoolbar_ButtonClick);
			// 
			// linebut
			// 
			this.linebut.ImageIndex = 0;
			this.linebut.ToolTipText = "Line";
			// 
			// rectbut
			// 
			this.rectbut.ImageIndex = 1;
			this.rectbut.ToolTipText = "Rectangle";
			// 
			// seperator
			// 
			this.seperator.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.seperator.Text = "toolBarButton1";
			// 
			// rectmenu
			// 
			this.rectmenu.Index = 1;
			this.rectmenu.Text = "&Rectangle";
			this.rectmenu.Click += new System.EventHandler(this.rectmenu_Click);
			// 
			// dash
			// 
			this.dash.Index = 2;
			this.dash.Text = "Dash";
			this.dash.Click += new System.EventHandler(this.dash_Click);
			// 
			// style
			// 
			this.style.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.soild,
																				  this.dot,
																				  this.dash,
																				  this.dashdot});
			// 
			// shapemenu
			// 
			this.shapemenu.Index = 0;
			this.shapemenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.linemenu,
																					  this.rectmenu,
																					  this.ellipsemenu});
			this.shapemenu.Text = "Shapes";
			// 
			// mymenu
			// 
			this.mymenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.shapemenu,
																				   this.colormenu});
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 273);
			this.ContextMenu = this.style;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.statusBar1,
																		  this.mytoolbar});
			this.Menu = this.mymenu;
			this.Name = "Form1";
			this.Text = "Drawing";
			((System.ComponentModel.ISupportInitialize)(this.shape)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		private void linemenu_Click(object sender, System.EventArgs e)
		{
			drawline() ;
		}
		private void rectmenu_Click(object sender, System.EventArgs e)
		{
			drawrect( ) ;
		}
		private void ellipsemenu_Click ( object sender, System.EventArgs e )
		{
			drawellipse( ) ;
		}
		private void rmenu_Click ( object sender, System.EventArgs e )
		{
			setrcolor( ) ;
		}
		private void gmenu_Click ( object sender, System.EventArgs e )
		{
			setgcolor( ) ;
		}
		private void bmenu_Click ( object sender, System.EventArgs e )
		{
			setbcolor( ) ;			
		}
		private void mytoolbar_ButtonClick ( object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e )
		{
			ToolBar.ToolBarButtonCollection b = mytoolbar.Buttons ;
			int index = b.IndexOf ( e.Button ) ;

			switch ( index )
			{
				case 0 : 
					drawline( ) ;
					break ;
				case 1 : 
					drawrect( ) ;
					break ;
				case 2 :
					drawellipse( ) ;
					break ;
				case 4 :
					setrcolor( ) ;
					break ;
				case 5 :
					setgcolor( ) ;
					break ;
				case 6 :
					setbcolor( ) ;
					break ;
			}
		}
		public void drawline( )
		{
			Invalidate() ;
			Update() ;

			gr.DrawLine ( mypen, 50, 50, 200, 200 ) ;

			linemenu.Enabled = false ;
			rectmenu.Enabled = true ;
			ellipsemenu.Enabled = true ;

			linebut.Enabled = false ;
			rectbut.Enabled = true ;
			ellipsebut.Enabled = true ;
			shape.Text = "Line" ;
		}

		public void drawrect( )
		{
			Invalidate() ;
			Update() ;

			gr.DrawRectangle ( mypen, 50, 70, 150, 100 ) ;
			linemenu.Enabled = true ;
			rectmenu.Enabled = false ;
			ellipsemenu.Enabled = true ;

			linebut.Enabled = true ;
			rectbut.Enabled = false ;
			ellipsebut.Enabled = true ;
			shape.Text = "Rectangle" ;
		}

		public void drawellipse( )
		{
			Invalidate() ;
			Update() ;
			Graphics gr = CreateGraphics() ;

			gr.DrawEllipse( mypen, 50, 70, 150, 100 ) ;

			linemenu.Enabled = true ;
			rectmenu.Enabled = true ;
			ellipsemenu.Enabled = false ;

			linebut.Enabled = true ;
			rectbut.Enabled = true ;
			ellipsebut.Enabled = false ;
			shape.Text = "Ellipse" ;
		}

		public void setrcolor( )
		{
			if ( r == 0 )
			{
				r = 255 ;
				redmenu.Checked = true ;
				redbut.Pushed = true ;
			}
			else
			{
				r = 0 ;
				redmenu.Checked = false ;
				redbut.Pushed = false ;
			}
			c = Color.FromArgb ( r, g, b ) ;
			mypen.Color = c ;
		}

		public void setgcolor( )
		{
			if ( g == 0 )
			{
				g = 255 ;
				greenmenu.Checked = true ;
				greenbut.Pushed = true ;
			}
			else
			{
				g = 0 ;
				greenmenu.Checked = false ;
				greenbut.Pushed = false ;
			}
			c = Color.FromArgb ( r, g, b ) ;
			mypen.Color = c ;
		}

		public void setbcolor( )
		{
			if ( b == 0 )
			{
				b = 255 ;
				bluemenu.Checked = true ;
				bluebut.Pushed = true ;
			}
			else
			{
				b = 0 ;
				bluemenu.Checked = false ;
				bluebut.Pushed = false ;
			}
			c = Color.FromArgb ( r, g, b ) ;
			mypen.Color = c ;
		}
		private void dot_Click ( object sender, System.EventArgs e)
		{
			mypen.DashStyle = DashStyle.Dot ;
		}

		private void dash_Click(object sender, System.EventArgs e)
		{
			mypen.DashStyle = DashStyle.Dash ;
		}

		private void dashdot_Click(object sender, System.EventArgs e)
		{
			mypen.DashStyle = DashStyle.DashDot ;
		}

		private void solid_Click(object sender, System.EventArgs e)
		{
			mypen.DashStyle = DashStyle.Solid ;
		}
	}
}