using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Sample
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.RadioButton male;
		protected System.Web.UI.WebControls.RadioButton female;
		protected System.Web.UI.WebControls.TextBox age;
		protected System.Web.UI.WebControls.DropDownList salary;
		protected System.Web.UI.WebControls.ListBox exp;
		protected System.Web.UI.WebControls.Button submit;
		protected System.Web.UI.WebControls.Label message;
		protected System.Web.UI.WebControls.RangeValidator RangeValidator1;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
		protected System.Web.UI.WebControls.TextBox name;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
	
		public WebForm1()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.submit.Click += new System.EventHandler(this.submit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
        #endregion

		private void submit_Click(object sender, System.EventArgs e)
		{
			string str = "Name:  " + name.Text + "<br>" ;
			str += "Age:  " + age.Text + "<br>"  ;
			str += "Salary:  " + salary.SelectedItem.Text + "<br>"  ;
			str += "Experience:  " + exp.SelectedItem.Text + "<br>"  ;
			str += "Gender:  " ;
			
			if ( male.Checked == true )
				str += "Male" ;

			if ( female.Checked == true )
				str += "Female" ; 

			message.Text = str ;

		}

		

	}
}
