using System ;
namespace sample 
{
	enum color
	{
		red = 8, blue, green = 7, yellow, brown
	}
	class Class1
	{
		static void Main ( string[ ] args )
		{
			Console.WriteLine ( ( int ) color.red + "   " + ( int ) color.yellow ) ;
		}
	}
}
