using System ;
namespace Sample
{
	public delegate void click( ) ;

	public class MyForm
	{
		public click  c1 ;
		public void mouseclick( )
		{
			c1( ) ;
		}
	}

	class MyForm1 : MyForm
	{
		public MyForm1( )
		{
			c1 = new click ( MyForm1_click ) ;
			mouseclick( ) ;

			c1 = new click ( button_click ) ;
			mouseclick( ) ;
		}
		static void Main ( string[ ] args )
		{
			MyForm1  f = new MyForm1( ) ;
		}

		public void  MyForm1_click( )
		{
			Console.WriteLine ( "Form clicked" ) ;
		}

		public static void  button_click( )
		{
			Console.WriteLine ( "Button clicked" ) ;
		}
	}
}
