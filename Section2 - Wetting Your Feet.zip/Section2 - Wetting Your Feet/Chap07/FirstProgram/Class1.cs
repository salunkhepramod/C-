namespace Simple
{
	using System ;

	class Class1
	{
		static void Main ( string[ ] args )
		{
			Console.WriteLine ( "Hello C#" ) ;
		}
	}
}

