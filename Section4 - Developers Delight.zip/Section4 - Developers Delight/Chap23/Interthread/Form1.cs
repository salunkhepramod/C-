using System ;
using System.Drawing ;
using System.Collections ;
using System.ComponentModel ;
using System.Windows.Forms ;
using System.Data ;
using System.Threading ;

namespace InterThread
{
	struct info
	{
		public int shapeno ;  
		public int x1, y1, x2, y2 ;
		public Pen p ;		
	};

	public class shapes
	{
		info[ ] n ; 
		Random  r ; 
		bool  flag ;
		Form1 f ;

		public shapes ( Form1 ff )
		{
			n = new info [ 10 ] ;
			r = new Random( ) ;
			flag = false ;
			f = ff ;
		}

		public void generatedata( )
		{
			int i = 0 ;
			while ( i != 10 )
			{
				i++ ;
				generate( ) ;
			}
		}		

		public void  generate(  )
		{
			Monitor.Enter ( n ) ;

			if ( flag )
				Monitor.Wait ( n ) ;

			Size sz = f.ClientSize ;

			for ( int i = 0 ; i < 10 ; i++ )
			{
				n[i].shapeno = r.Next ( 3 ) ;
				n[i].x1 = r.Next ( sz.Width ) ;
				n[i].y1 = r.Next ( sz.Height ) ;
				n[i].x2 = r.Next ( sz.Height - n[i].y1 ) ;
				n[i].y2 = r.Next ( sz.Width - n[i].x1 ) ;
				Color c = Color.FromArgb ( r.Next ( 255 ), r.Next ( 255 ), r.Next ( 255 ) ) ;
				n[i].p = new Pen ( c, 3 ) ;
				Thread.Sleep ( 10 ) ;
			}

			MessageBox.Show ( "Generate" ) ;

			flag = true ;
			Monitor.Pulse ( n ) ;
			Monitor.Exit ( n ) ;
		}

		public void drawdata ( )
		{
			int i = 0 ;
			while ( i != 10 )
			{
				i++ ;
				draw() ;
			}
		}

		public void draw( )
		{
			Monitor.Enter ( n ) ;
			if ( !flag )
				Monitor.Wait ( n ) ;

			Graphics g = f.CreateGraphics( ) ;	
	
			Thread.Sleep ( 100 ) ;
			for ( int i = 0 ; i < 10 ; i++ )
			{
				switch ( n[i].shapeno )
				{
					case 0:
						g.DrawLine ( n[i].p, n[i].x1, n[i].y1, n[i].x2, n[i].y2 ) ;
						break ;

					case 1:
						g.DrawRectangle ( n[i].p, n[i].x1, n[i].y1, n[i].x2, n[i].y2 ) ;
						break ;

					case 2:
						g.DrawEllipse ( n[i].p, n[i].x1, n[i].y1, n[i].x2, n[i].y2 ) ;
						break ;
				}
			}
			MessageBox.Show ( "Draw" ) ;
			flag = false ;
			Monitor.Pulse ( n ) ;
			Monitor.Exit ( n ) ;
		}
	}
	public class Form1 : System.Windows.Forms.Form
	{
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if ( disposing )
			{
				if (components != null) 
				{
					components.Dispose( ) ;
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(384, 285);
			this.Name = "Form1";
			this.Text = "Drawing";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);

		}
		#endregion
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// 

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_MouseDown ( object sender, System.Windows.Forms.MouseEventArgs e )
		{
				shapes s = new shapes ( this ) ;

				ThreadStart ts1 = new ThreadStart ( s.generatedata ) ;
				Thread t1 = new Thread ( ts1  ) ;
				t1.Start() ;

				ThreadStart ts2 = new ThreadStart ( s.drawdata ) ;
				Thread t2 = new Thread ( ts2 ) ;
				t2.Start() ;
		}
	}
}

