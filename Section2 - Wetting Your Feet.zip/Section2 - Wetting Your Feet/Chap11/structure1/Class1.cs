using System ;
namespace sample
{
	struct employee
	{
		string name ;
		int age ;
		float sal ;

		public employee ( string  n, int a, float s )
		{
			name = n ;
			age = a ;
			sal = s ;
		}

		public void showdata( )
		{
			Console.WriteLine ( "Name: " + name ) ;
			Console.WriteLine ( "Age: " + age ) ;
			Console.WriteLine ( "Salary: " + sal ) ;
		}
	}

	class Class1
	{
		static void Main ( string[ ] args )
		{
			employee e1 = new employee ( "Amit", 35, 25000 ) ;
			e1.showdata( ) ;
		}
	}
}
