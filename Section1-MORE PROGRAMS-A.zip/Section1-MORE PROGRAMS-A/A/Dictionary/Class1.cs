using System ;
using System.Collections ;
namespace dictionary
{
	public class Class1
	{
		public static int Main ( string[] args )
		{
			dict d = new dict ( ) ;
			bool cont = true ;
			Console.WriteLine ( " ========================================= " ) ;
			Console.WriteLine ( "                Dictionary                 " ) ;
			Console.WriteLine ( " ========================================= " ) ;
			Console.WriteLine ( "" ) ;
			while (cont)
			{
				int choice = d.showmenu( ) ;
				switch (choice)
				{
					case 1:
						//search meaning
						d.searchmeanofword ( ) ;
						break ;
					case 2:
						d.searchword();
						break ;
						// search word
					case 3:
						// add
						d.add ( ) ;
						break ;
					case 4:
						d.addmean();
						break;
					case 5:
						//del
						d.del ( ) ;
						break ;
					case 6:
						// see words
						d.showkey ( ) ;
						break ;
					case 7:
						//exit
						Console.WriteLine ( "" ) ;
						Console.WriteLine ( " ========================================= " ) ; 
						Console.WriteLine ( "                Good Bye                   " ) ;
						Console.WriteLine ( " ========================================= " ) ;
						Console.WriteLine ( "" ) ;
						cont = false ;
						break ;
					default:
						Console.WriteLine ( " Wrong input, choose again " ) ;
						break ;
				}	 
			}
			return 0 ;
		}
	}

	public class dict
	{
		public SortedList[] alpha =  new SortedList[26] ;
		
		public dict ( )
		{
		}
		public int showmenu ( )
		{
			Console.WriteLine ( "" ) ;
			Console.WriteLine ( " (1) Search a meaning for the word " ) ;
			Console.WriteLine ( " (2) Search a word for the meaning " ) ;
			Console.WriteLine ( " (3) Add a word and meaning " ) ;
			Console.WriteLine ( " (4) Add a meaning " ) ;
			Console.WriteLine ( " (5) Delete a word and meaning" ) ;
			Console.WriteLine ( " (6) See words and meanings for a particular letter" ) ;
			Console.WriteLine ( " (7) Exit" ) ;
			Console.WriteLine ( "" ) ;
			return Int32.Parse ( Console.ReadLine ( ) ) ;
		}

		public void add ( )
		{		
			Console.WriteLine ( " Enter word " ) ;
			string wrd = Console.ReadLine ( ) ;
			int index = wrd[0] - 97 ;
			Console.WriteLine ( " How many meanings u wish to enter " ) ;
			int num = Int32.Parse(Console.ReadLine ( ) ) ;
			string[] mean = new string[num];
			for(int x = 0 ; x< num ; x++)
			{
				Console.WriteLine ( " Enter meaning {0}", x + 1 ) ;
				mean[x] = Console.ReadLine ( ) ;	
			}
			if ( alpha[index] == null)
				alpha[index] = new SortedList() ;

			alpha[index].Add ( wrd, mean ) ; 
			Console.WriteLine ( " Word added! " ) ;		
		}

		public void del (  )
		{
			Console.WriteLine ( " Enter word ") ;
			string wrd = Console.ReadLine ( ) ;
			int index = wrd[0] - 97 ;
			alpha[index].Remove ( wrd ) ;
			Console.WriteLine( " Word deleted! " ) ;
		}
		
		public void searchmeanofword ( )
		{
			Console.WriteLine ( " Enter the word whose meaning u want to know" ) ;
			string wrd = Console.ReadLine ( ) ;

			int index = wrd[0] - 97 ;

			if ( alpha[index] != null &&  alpha[index].ContainsKey ( wrd ) )
			{
				int i = alpha[index].IndexOfKey ( wrd ) ;
				Console.WriteLine( i ) ;
				string[] mn = ( string[] ) alpha[index].GetByIndex ( i ) ;
				for(int x = 0 ; x < mn.Length ; x++ )
				{
					Console.WriteLine ( " {0} means {1} " , wrd , mn[x] ) ;
				}
			}
			else
				Console.WriteLine ( " This word does not exist in the dictionary " ) ;
		}

		public void searchword ( )
		{
			Console.WriteLine ( " Enter the  meaning for which u r searching a word" ) ;
			string mn = Console.ReadLine ( ) ;
			int i, j, k ;
			bool present = false;
			string wrd = "";
			for ( i = 0 ; i < 26 ; i++ )
			{
				if ( alpha[i] != null )
				{
					for ( j = 0 ; j < alpha[i].Count  ; j++ )
					{
						string [ ] arr = ( string[] ) alpha[i].GetByIndex ( j ) ;
						for ( k = 0 ; k < arr.Length ; k++ )
						{
							if ( mn == arr[k] )
							{
								present = true ;
								break ;
							}
						}
						if ( present )
						{	
							wrd = ( string ) alpha[i].GetKey ( j ) ;
							Console.WriteLine ( " Closest match for {0} is {1} " , mn , wrd ) ;
							present = false ;
						}
					}
				}
			}
		}

		public void showkey ( )
		{
			Console.WriteLine ( " See keys for which letter " ) ;			
			
			char ind = Char.Parse ( Console.ReadLine ( ) ) ;
			int index = ind - 97 ;
			IDictionaryEnumerator E = alpha[index].GetEnumerator ( ) ;
			while ( E.MoveNext( ) )
			{
				Console.Write("\nMeanings for the word {0} are: [ ", E.Key ) ;
				string[] arr = (string[])E.Value ;
				for (int i = 0 ;i < arr.Length ; i++ )
					Console.Write ( arr[i] + "  " ) ;

				Console.Write ("]\n") ;
				
			}
		}

		public void addmean()
		{
		
			Console.WriteLine ( " Add meaning for which word " );
			string wrd = Console.ReadLine ( ) ;
			Console.WriteLine ( " Add meaning " );
			string mean = Console.ReadLine ( );
			int index = wrd[0] - 97 ;

			if ( alpha[index] != null &&  alpha[index].ContainsKey(wrd) )
			{
				int i = alpha[index].IndexOfKey ( wrd ) ;
				string[ ] mn = ( string[] ) alpha[index].GetByIndex ( i ) ;
				string[ ] temp = new string [ mn.Length + 1 ] ;
				Console.WriteLine( mn.Length ) ;
				mn.CopyTo(temp,0);
				temp[ mn.Length ] = mean ;
				alpha[index].Remove ( wrd ) ;
				alpha[index].Add ( wrd, temp ) ;
				Console.WriteLine ( " meaning added succesfully " ) ;
			}
			else
				Console.WriteLine ( " This word does not exist in the dictionary " ) ;
		}
	}
}
