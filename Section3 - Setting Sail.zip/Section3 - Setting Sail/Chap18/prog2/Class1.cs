using System ;
namespace Sample
{
	public class mouseeventargs
	{
		public int x, y ;
		public mouseeventargs ( int x1, int y1 )
		{
			x = x1 ;
			y = y1 ;
		}
	}

	public delegate void click ( object m, mouseeventargs e ) ;

	public class MyForm
	{
		public event click  c1 ;
		public void mouseclick( )
		{
			mouseeventargs m = new mouseeventargs ( 10, 20 ) ;
			c1 ( this, m ) ;
		}
	}
	class MyForm1 : MyForm
	{
		public MyForm1()
		{
			c1 += new click ( button_click ) ; 
			mouseclick( ) ;
		}
		static void Main ( string[ ] args )
		{
			MyForm1 f = new MyForm1( ) ;
		}

		public void  button_click ( object m, mouseeventargs e )
		{
			Console.WriteLine ( "Mouse Coordinates: " + e.x + " " + e.y ) ;
			Console.WriteLine ( "Type is: " + m.GetType( ).ToString( ) ) ;
		}
	}
}
