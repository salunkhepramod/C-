using System ;
using System.Drawing ;
using System.Windows.Forms ;

namespace fontassembly
{
	public class mytext
	{		
		public void display ( Form fr, string s, Color c, string fname, int size, Point pt )
		{
			Graphics g = fr.CreateGraphics( ) ;
			Font myfont = new Font ( fname, size, FontStyle.Italic )  ;
			SolidBrush mybrush = new SolidBrush ( c ) ;
			g.DrawString ( s, myfont, mybrush, pt ) ;
		}
	}
}
