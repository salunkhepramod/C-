using System ;
namespace Sample
{
	public class Class1
	{
		static void Main ( string[ ] args )
		{
			myclass m = new myclass( ) ;
			try
			{
				m.fun ( 20 ) ;
			}
			catch ( Exception e )
			{
				Console.WriteLine ( e ) ;
			}
		}
	}
	class myclass
	{
		public void fun ( int i )
		{
			if ( i > 10 )
				throw new Exception ( "Value out of range" ) ;
			else
				Console.WriteLine ( i ) ;
		}
	}
}
