using System;
namespace StaticDemo
{
	class sample
	{
		private static int count ;

		public sample( )
		{
			count++  ;
		}

		public static void showcount( )
		{
			Console.WriteLine ( "Value of Count is: " + count ) ;
		}
	}
	class Class1
	{
		static void Main ( string [ ] args )
		{
			sample s1 = new sample( ) ;
			sample.showcount( ) ;

			sample s2 = new sample( ) ;
			sample.showcount( ) ;
		}
	}
}
