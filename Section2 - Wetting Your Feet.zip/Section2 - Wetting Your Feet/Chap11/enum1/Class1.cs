using System ;
namespace sample 
{
	enum color
	{
		red, blue, green
	}
	class Class1
	{
		static void Main ( string[ ] args )
		{
			Console.WriteLine ( "{0} ", color.red ) ;
		}
	}
}
