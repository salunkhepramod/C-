using System ;
using System.Drawing ;
using System.Collections ;
using System.ComponentModel ;
using System.Windows.Forms ;
using System.Data ;
using System.IO ;
using System.Threading ;
using System.Runtime.Serialization ;
using System.Runtime.Serialization.Formatters.Binary;

namespace myapp
{
	[Serializable]
	abstract class shapes 
	{
		protected int  r, g, b ;
		
		public shapes( )
		{
			Random rd = new Random( ) ;
			r = rd.Next ( 255 ) ;
			g = rd.Next ( 255 ) ;
			b = rd.Next ( 255 ) ;

			// put the thread to sleep for next 5 
			// milliseconds to ensure proper color 
			// generation
			Thread.Sleep ( 5 ) ;
		}
		public abstract void draw ( Graphics g ) ;
	}	

	[Serializable]
	class line : shapes 
	{
		int x1, y1 ;
		int x2, y2 ;
		public line ( int i, int j, int k, int l )
		{
			x1 =  i ;
			y1 =  j ;
			x2 =  k ;
			y2 =  l ;
		}

		public override void draw ( Graphics gg ) 
		{
			Color c =  Color.FromArgb ( r, g, b ) ;
			Pen p = new Pen ( c, 4 ) ;
			gg.DrawLine ( p, x1, y1, x2, y2 ) ;
		}
	}

	[Serializable]
	class rectangle : shapes 
	{
		int x1, y1 ;
		int width, height ;

		public rectangle ( int x, int y, int h, int w )
		{
			x1 = x ;
			y1 = y ;
			height = h ;
			width = w ;
		}
		public override void draw ( Graphics gg ) 
		{
			Color c =  Color.FromArgb ( r, g, b ) ;
			Pen p = new Pen ( c, 4 ) ;
			gg.DrawRectangle ( p, x1, y1, width, 
				height ) ;
		}
	}
	[Serializable]
	class ellipse : shapes 
	{
		int x1, y1 ;
		int width, height ;

		public ellipse ( int x, int y, int h, int w )
		{
			x1 = x ;
			y1 = y ;
			height = h ;
			width = w ;
		}
		public override void draw ( Graphics gg ) 
		{
			Color c =  Color.FromArgb ( r, g, b ) ;
			Pen p = new Pen ( c, 4 ) ;
			gg.DrawEllipse ( p, x1, y1, width, height ) ;
		}
	}

	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu 
			mainMenu1 ;
		private System.Windows.Forms.MenuItem 
			menuItem1 ;
		private System.Windows.Forms.MenuItem 
			filenew ;
		private System.Windows.Forms.MenuItem 
			exit ;
		private System.ComponentModel.Container 
			components = null ;

		ArrayList s = new ArrayList( ) ;

		private System.Windows.Forms.MenuItem save;
		private System.Windows.Forms.MenuItem generate;
		private System.Windows.Forms.MenuItem open;
		BinaryFormatter b = new BinaryFormatter ( ) ;

		public Form1( )
		{
			InitializeComponent( ) ;
		}

		protected override void Dispose ( bool 
			disposing )
		{
			if( disposing )
			{
				if ( components != null ) 
				{
					components.Dispose( ) ;
				}
			}
			base.Dispose( disposing ) ;
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.exit = new System.Windows.Forms.MenuItem();
			this.save = new System.Windows.Forms.MenuItem();
			this.generate = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.filenew = new System.Windows.Forms.MenuItem();
			this.open = new System.Windows.Forms.MenuItem();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			// 
			// exit
			// 
			this.exit.Index = 4;
			this.exit.Text = "Exit";
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// save
			// 
			this.save.Index = 2;
			this.save.Text = "Save";
			this.save.Click += new System.EventHandler(this.save_Click);
			// 
			// generate
			// 
			this.generate.Index = 3;
			this.generate.Text = "Generate";
			this.generate.Click += new System.EventHandler(this.generate_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.filenew,
																					 this.open,
																					 this.save,
																					 this.generate,
																					 this.exit});
			this.menuItem1.Text = "File";
			// 
			// filenew
			// 
			this.filenew.Index = 0;
			this.filenew.Text = "New";
			this.filenew.Click += new System.EventHandler(this.filenew_Click);
			// 
			// open
			// 
			this.open.Index = 1;
			this.open.Text = "Open";
			this.open.Click += new System.EventHandler(this.open_Click);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(328, 249);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Serialization Demo";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		[STAThread]
		static void Main( ) 
		{
			Application.Run ( new Form1 ( ) ) ;
		}

		private void open_Click ( object sender, 
			System.EventArgs e )
		{
			OpenFileDialog od = new 
				OpenFileDialog( ) ;
			od.Filter = "dat files ( *.dat )|*.dat"  ;

			if ( od.ShowDialog( ) == DialogResult.OK )
			{
				FileInfo f=new FileInfo ( od.FileName) ;
				Stream st = f.Open ( FileMode.Open ) ;

				while ( st.Position != st.Length )
					s.Add ( b.Deserialize ( st ) ) ;

				st.Close ( ) ;
			}
			Invalidate( ) ;
		}

		private void save_Click ( object sender, 
			System.EventArgs e )
		{
			SaveFileDialog sd = new 
				SaveFileDialog( );
			sd.Filter = "dat files ( *.dat ) | *.dat"  ;

			if ( sd.ShowDialog( ) == DialogResult.OK )
			{
				FileInfo f = new FileInfo(sd.FileName ) ;
				Stream st = f.Open ( FileMode.Create, 
					FileAccess.ReadWrite ) ;
				foreach ( shapes ss in  s )
					b.Serialize ( st, ss ) ;

				st.Close ( ) ;
			}
		}

		private void generate_Click ( object 
			sender, System.EventArgs e )
		{
			Size sz = ClientSize ;
			Random rd  = new Random( ) ;

			for ( int i = 0 ; i < 10 ; i++ )
			{
				int shapeno = rd.Next ( 3 ) ;
				int x1 = rd.Next ( sz.Width ) ;
				int y1 = rd.Next ( sz.Height ) ;
				int x2 = rd.Next ( sz.Height - y1 ) ;
				int y2 = rd.Next ( sz.Width - x1 ) ;

				switch ( shapeno )
				{
					case 0:
						s.Add ( new line ( x1, y1, x2, 
							y2 ) ) ;
						break ;
					case 1:
						s.Add ( new rectangle ( x1, y1, 
							x2, y2 ) ) ;
						break ;
					case 2:
						s.Add ( new ellipse ( x1, y1, 
							x2, y2 ) ) ;
						break ;
				}
			}
			Invalidate( ) ;
		}

		private void exit_Click ( object sender, 
			System.EventArgs e )
		{
			Dispose( ) ;
		}

		private void Form1_Paint ( object sender, 
			System.Windows.Forms.PaintEventArgs e )
		{
			Graphics g = e.Graphics ;
			foreach ( shapes ss in  s )
				ss.draw ( g ) ;
		}

		private void filenew_Click ( object sender, 
			System.EventArgs e )
		{
			s.Clear( ) ;
			Invalidate( ) ;
		}
	}
}
