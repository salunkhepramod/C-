using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Threading ;
using System.IO ;

namespace CriticalSection
{
	class mythread
	{
		ListBox list ;
		ArrayList arr ;
		string name ;
		public mythread ( ListBox l, ArrayList a )
		{
			list = l ;
			arr = a ;
		}
		public mythread ( ListBox l, ArrayList a, string n )
		{
			list = l ;
			arr = a ;
			name = n ;
		}
		public void add( )
		{
			lock ( arr )
			{
				arr.Add ( name ) ;
				list.Items.Clear( ) ;
				foreach ( string i in arr )
					list.Items.Add ( i ) ;
			}
		}
		public void sort( )
		{
			lock ( arr )
			{
				arr.Sort() ;
				list.Items.Clear( ) ;
				foreach ( string i in arr )
					list.Items.Add ( i ) ;
			}
		}
	}

	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button add ;
		private System.Windows.Forms.TextBox name ;
		private System.Windows.Forms.Button sort ;
		private System.Windows.Forms.ListBox list;
		private System.Windows.Forms.Button close;
		private System.ComponentModel.Container components = null;
		
		ArrayList arr = new ArrayList( ) ;
		public Form1()
		{
			InitializeComponent();

			FileInfo f  = new FileInfo ( "data.txt") ;
			StreamReader r = f.OpenText ( ) ;
			string s ;

			while ( ( s = r.ReadLine( ) ) != null )
			{
				arr.Add ( s ) ;				
				list.Items.Add ( s ) ;
			}
			r.Close() ;
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.close = new System.Windows.Forms.Button();
			this.sort = new System.Windows.Forms.Button();
			this.name = new System.Windows.Forms.TextBox();
			this.list = new System.Windows.Forms.ListBox();
			this.add = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// close
			// 
			this.close.Location = new System.Drawing.Point(72, 216);
			this.close.Name = "close";
			this.close.TabIndex = 5;
			this.close.Text = "Close";
			this.close.Click += new System.EventHandler(this.close_Click);
			// 
			// sort
			// 
			this.sort.Location = new System.Drawing.Point(18, 67);
			this.sort.Name = "sort";
			this.sort.Size = new System.Drawing.Size(64, 24);
			this.sort.TabIndex = 3;
			this.sort.Text = "Sort";
			this.sort.Click += new System.EventHandler(this.sort_Click);
			// 
			// name
			// 
			this.name.Location = new System.Drawing.Point(96, 26);
			this.name.Name = "name";
			this.name.Size = new System.Drawing.Size(120, 20);
			this.name.TabIndex = 1;
			this.name.Text = "";
			// 
			// list
			// 
			this.list.Location = new System.Drawing.Point(96, 63);
			this.list.Name = "list";
			this.list.Size = new System.Drawing.Size(120, 134);
			this.list.TabIndex = 2;
			// 
			// add
			// 
			this.add.Location = new System.Drawing.Point(16, 24);
			this.add.Name = "add";
			this.add.Size = new System.Drawing.Size(64, 24);
			this.add.TabIndex = 0;
			this.add.Text = "Add";
			this.add.Click += new System.EventHandler(this.add_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(240, 261);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.close,
																		  this.sort,
																		  this.list,
																		  this.name,
																		  this.add});
			this.Name = "Form1";
			this.Text = "Critical Section";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void add_Click ( object sender, System.EventArgs e )
		{
			string n = name.Text ;
			name.Text = "" ;
			mythread mt = new mythread ( list, arr, n ) ;

			ThreadStart ts = new ThreadStart ( mt.add ) ;
			Thread t = new Thread ( ts ) ;
			t.Start( ) ;
		}

		private void sort_Click(object sender, System.EventArgs e)
		{
			mythread m = new mythread ( list, arr ) ;

			ThreadStart ts = new ThreadStart ( m.sort ) ;
			Thread t = new Thread ( ts ) ;
			t.Start( ) ;
		}

		private void close_Click ( object sender, System.EventArgs e )
		{
			Dispose() ;
		}

	}
}
