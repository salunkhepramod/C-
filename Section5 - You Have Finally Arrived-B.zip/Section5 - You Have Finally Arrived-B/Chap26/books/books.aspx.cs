using System ; 
using System.Collections ; 
using System.ComponentModel ;
using System.Data ;
using System.Drawing ;
using System.Web ;
using System.Web.SessionState ;
using System.Web.UI ;
using System.Web.UI.WebControls ;
using System.Web.UI.HtmlControls ;
using System.Data.OleDb ;

namespace books
{
	public class WebForm1 : System.Web.UI.Page
	{
		string constr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\\books.mdb" ;
		protected System.Web.UI.WebControls.Button show ;
		protected System.Web.UI.WebControls.DataList list;
		protected System.Web.UI.WebControls.DataList DataList1;
		protected System.Web.UI.WebControls.DropDownList sub;
		protected System.Web.UI.HtmlControls.HtmlForm Form1 ;

		public WebForm1()
		{
			Page.Init += new System.EventHandler ( Page_Init ) ;
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !Page.IsPostBack )
			{
				string cmdstr = "select distinct subject from bookinfo" ;
				OleDbDataAdapter adpt = new OleDbDataAdapter ( cmdstr, constr ) ;
				DataSet ds = new DataSet( ) ;
				adpt.Fill ( ds, "bookinfo" ) ;
				DataTable dt = ds.Tables [ "bookinfo" ] ;

				sub.DataSource  = dt ;
				sub.DataBind() ;
			}
		}

		private void Page_Init ( object sender, EventArgs e )
		{
			InitializeComponent() ;
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.show.Click += new System.EventHandler(this.show_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		private void show_Click ( object sender, System.EventArgs e )
		{
			string cmdstr = "select * from bookinfo where subject= '" +  sub.SelectedItem + "'" ;
			OleDbDataAdapter adpt = new OleDbDataAdapter ( cmdstr, constr ) ;
			DataSet ds = new DataSet( ) ;
			adpt.Fill ( ds, "bookinfo" ) ;
			DataTable dt = ds.Tables["bookinfo"] ;

			list.DataSource  = dt ;
			list.DataBind( ) ;

		}
	}
}
