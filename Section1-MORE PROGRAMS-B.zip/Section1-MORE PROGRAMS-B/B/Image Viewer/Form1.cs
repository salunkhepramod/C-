using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO ;
using System.Threading ;
namespace Explorer
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Panel mypanel;
		private System.Windows.Forms.PictureBox pic;
		private System.Windows.Forms.ListView list;
		private System.Windows.Forms.TreeView tree;
		private System.Windows.Forms.StatusBar mysbar;
		private System.Windows.Forms.StatusBarPanel myspanel1;
		private System.Windows.Forms.StatusBarPanel myspanel2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private string selpath;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			adddrives( );

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		public void adddrives( )
		{
			string[] drives = Directory.GetLogicalDrives( ) ;
			foreach ( string i in drives )
			{
				TreeNode t = new TreeNode( ) ;
				if ( i != "A:\\" )
				{
					t = tree.Nodes.Add ( i ) ;
					t.Nodes.Add(" ") ;
				}
			}
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tree = new System.Windows.Forms.TreeView();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.list = new System.Windows.Forms.ListView();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.mypanel = new System.Windows.Forms.Panel();
			this.pic = new System.Windows.Forms.PictureBox();
			this.mysbar = new System.Windows.Forms.StatusBar();
			this.myspanel1 = new System.Windows.Forms.StatusBarPanel();
			this.myspanel2 = new System.Windows.Forms.StatusBarPanel();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.mypanel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.myspanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.myspanel2)).BeginInit();
			this.SuspendLayout();
			// 
			// tree
			// 
			this.tree.ImageIndex = -1;
			this.tree.Location = new System.Drawing.Point(16, 24);
			this.tree.Name = "tree";
			this.tree.SelectedImageIndex = -1;
			this.tree.Size = new System.Drawing.Size(136, 256);
			this.tree.TabIndex = 1;
			this.tree.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.tree_AfterExpand);
			this.tree.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.tree_AfterCollapse);
			this.tree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tree_AfterSelect);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.tree});
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(168, 296);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "List";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.list});
			this.groupBox2.Location = new System.Drawing.Point(200, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(168, 296);
			this.groupBox2.TabIndex = 0;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Files";
			// 
			// list
			// 
			this.list.Location = new System.Drawing.Point(16, 24);
			this.list.Name = "list";
			this.list.Size = new System.Drawing.Size(136, 256);
			this.list.TabIndex = 1;
			this.list.View = System.Windows.Forms.View.List;
			this.list.SelectedIndexChanged += new System.EventHandler(this.list_SelectedIndexChanged);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.mypanel});
			this.groupBox3.Location = new System.Drawing.Point(392, 8);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(168, 296);
			this.groupBox3.TabIndex = 0;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Image";
			// 
			// mypanel
			// 
			this.mypanel.AutoScroll = true;
			this.mypanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.mypanel.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.pic});
			this.mypanel.Location = new System.Drawing.Point(16, 24);
			this.mypanel.Name = "mypanel";
			this.mypanel.Size = new System.Drawing.Size(136, 256);
			this.mypanel.TabIndex = 1;
			// 
			// pic
			// 
			this.pic.Name = "pic";
			this.pic.Size = new System.Drawing.Size(224, 360);
			this.pic.TabIndex = 0;
			this.pic.TabStop = false;
			// 
			// mysbar
			// 
			this.mysbar.Location = new System.Drawing.Point(0, 317);
			this.mysbar.Name = "mysbar";
			this.mysbar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																					  this.myspanel1,
																					  this.myspanel2});
			this.mysbar.ShowPanels = true;
			this.mysbar.Size = new System.Drawing.Size(576, 24);
			this.mysbar.TabIndex = 1;
			// 
			// myspanel1
			// 
			this.myspanel1.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
			this.myspanel1.Width = 275;
			// 
			// myspanel2
			// 
			this.myspanel2.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
			this.myspanel2.Width = 275;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 341);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.mysbar,
																		  this.groupBox1,
																		  this.groupBox2,
																		  this.groupBox3});
			this.Name = "Form1";
			this.Text = "Explorer";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.mypanel.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.myspanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.myspanel2)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void tree_AfterExpand(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			TreeNode t = e.Node ;
			DirectoryInfo d = null ; 			
			if ( t.Parent == null )
			{
				t.Nodes.RemoveAt ( 0 ) ;
				d = new DirectoryInfo ( e.Node.Text ) ;
				Check ( d, t ) ; 
			}
		}

		public static void Check ( DirectoryInfo d, TreeNode t )
		{
			FileSystemInfo[] f = d.GetFileSystemInfos() ;
			foreach ( FileSystemInfo i in f )
			{
				if ( i.Attributes == FileAttributes.Directory )
				{
					DirectoryInfo d1 = new DirectoryInfo ( i.FullName ) ;
					TreeNode t1 = t.Nodes.Add ( i.Name ) ;
					Check ( d1, t1 ) ; 
				}
			}
		}

		private void tree_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			selpath = getpath ( e.Node ) ;
			DirectoryInfo d = new DirectoryInfo(selpath);
			FileInfo[] f = d.GetFiles( ) ;
			int n = 0 ;
			list.Clear( ) ;
			list.Invalidate( ) ;
			foreach ( FileInfo i in f )
			{
				string str = i.Extension;
				if ( str == ".bmp" || str == ".jpg" || str == ".gif" )
				{
					list.Items.Add ( i.Name,n ) ;
					n++ ;
				}
			}
		}
		string getpath ( TreeNode h )
		{
			string result = h.Text ;
			TreeNode hparent ;
			while ( ( hparent = h.Parent ) != null )
			{
				string str = hparent.Text ;
				if ( !str.EndsWith("\\" ) ) 
					str += "\\" ;
				result = str + result ;
				h = hparent ;
			}
			return result;
		}

		private void list_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string str = list.FocusedItem.Text;
			if ( !selpath.EndsWith("\\" ) ) 
				selpath += "\\" ;
			str = selpath + str ;
			Image img = Image.FromFile ( str ) ;
			FileInfo f = new FileInfo(str) ;
			myspanel1.Text = "Path: " + f.FullName ;
			myspanel2.Text = "Size in bytes: " + f.Length ;
			pic.Width = img.Width ;
			pic.Height = img.Height ;
			pic.Image = img;
		}
		private void tree_AfterCollapse(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			e.Node.Nodes.Clear() ;	
			e.Node.Nodes.Add(" ") ;
		}	
	}
}
