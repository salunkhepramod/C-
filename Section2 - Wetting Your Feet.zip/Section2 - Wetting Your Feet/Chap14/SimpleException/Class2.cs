using System;

namespace SimpleException
{
	/// <summary>
	/// Summary description for Class2.
	/// </summary>
	public class Class2
	{
		public Class2()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
