The 'cominterop' includes two programs, one  'AtlServer' and the other 'latebinding'.

In AtlServer we have created a CMath class representing a COM component. This class has two methods - one to add two numbers and the other to subtract two numbers. Build the 'AtlServer' application and register the COM component.

The 'latebinding' program is a console application in which we have used this COM component.