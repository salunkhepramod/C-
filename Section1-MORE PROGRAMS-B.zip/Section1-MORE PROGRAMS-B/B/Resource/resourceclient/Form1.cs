using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection ;
using System.Resources ;

namespace resourseclient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		///
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox pub;
		private System.Windows.Forms.TextBox title;
		private System.Windows.Forms.TextBox subject;
		private System.Windows.Forms.TextBox pages;
		private System.Windows.Forms.TextBox author;
		private System.Windows.Forms.TextBox cat;
		private System.Windows.Forms.PictureBox luc;
		
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			Assembly asm = Assembly.GetExecutingAssembly() ;
			
			ResourceManager rm = new ResourceManager ( "resourseclient.Demo",asm ) ;
			luc.Image = (Image) rm.GetObject("logo");

			title.Text = rm.GetString ( "Title" ) ;
			author.Text = rm.GetString ( "Author" ) ;
			subject.Text = rm.GetString ( "Subject" ) ;
			pages.Text = rm.GetString ( "Pages" ) ;
			pub.Text = rm.GetString ( "Publisher" ) ;
			cat.Text = rm.GetString ( "Category" ) ;
		}
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pub = new System.Windows.Forms.TextBox();
			this.title = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.cat = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.luc = new System.Windows.Forms.PictureBox();
			this.label5 = new System.Windows.Forms.Label();
			this.subject = new System.Windows.Forms.TextBox();
			this.pages = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.author = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// pub
			// 
			this.pub.Location = new System.Drawing.Point(248, 176);
			this.pub.Name = "pub";
			this.pub.ReadOnly = true;
			this.pub.Size = new System.Drawing.Size(112, 20);
			this.pub.TabIndex = 3;
			this.pub.Text = "";
			// 
			// title
			// 
			this.title.Location = new System.Drawing.Point(248, 16);
			this.title.Name = "title";
			this.title.ReadOnly = true;
			this.title.Size = new System.Drawing.Size(112, 20);
			this.title.TabIndex = 1;
			this.title.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(184, 96);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 23);
			this.label2.TabIndex = 5;
			this.label2.Text = "Subject:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(184, 136);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 24);
			this.label3.TabIndex = 6;
			this.label3.Text = "Pages:";
			// 
			// cat
			// 
			this.cat.Location = new System.Drawing.Point(248, 216);
			this.cat.Name = "cat";
			this.cat.ReadOnly = true;
			this.cat.Size = new System.Drawing.Size(112, 20);
			this.cat.TabIndex = 1;
			this.cat.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(184, 56);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 23);
			this.label1.TabIndex = 4;
			this.label1.Text = "Author:";
			// 
			// luc
			// 
			this.luc.Location = new System.Drawing.Point(24, 48);
			this.luc.Name = "luc";
			this.luc.Size = new System.Drawing.Size(128, 152);
			this.luc.TabIndex = 0;
			this.luc.TabStop = false;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(184, 16);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 23);
			this.label5.TabIndex = 7;
			this.label5.Text = "Title:";
			// 
			// subject
			// 
			this.subject.Location = new System.Drawing.Point(248, 96);
			this.subject.Name = "subject";
			this.subject.ReadOnly = true;
			this.subject.Size = new System.Drawing.Size(112, 20);
			this.subject.TabIndex = 2;
			this.subject.Text = "";
			// 
			// pages
			// 
			this.pages.Location = new System.Drawing.Point(248, 136);
			this.pages.Name = "pages";
			this.pages.ReadOnly = true;
			this.pages.Size = new System.Drawing.Size(112, 20);
			this.pages.TabIndex = 3;
			this.pages.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(184, 176);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 24);
			this.label4.TabIndex = 6;
			this.label4.Text = "Publisher:";
			// 
			// author
			// 
			this.author.Location = new System.Drawing.Point(248, 56);
			this.author.Name = "author";
			this.author.ReadOnly = true;
			this.author.Size = new System.Drawing.Size(112, 20);
			this.author.TabIndex = 1;
			this.author.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(184, 216);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(56, 23);
			this.label6.TabIndex = 7;
			this.label6.Text = "Category:";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 269);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cat,
																		  this.label6,
																		  this.title,
																		  this.label5,
																		  this.pub,
																		  this.label4,
																		  this.label3,
																		  this.label2,
																		  this.label1,
																		  this.pages,
																		  this.subject,
																		  this.author,
																		  this.luc});
			this.Name = "Form1";
			this.Text = "Book Info";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
