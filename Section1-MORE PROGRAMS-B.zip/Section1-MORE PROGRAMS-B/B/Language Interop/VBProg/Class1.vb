Imports mcppprog
Public Class myvbclass
    Inherits mymcppclass
    Public Overrides Sub func2()
        MyBase.func2()
        System.Console.WriteLine("In func2 of Visual Basic class")
    End Sub
    Public Sub func3()
        System.Console.WriteLine("In func3 of Visual Basic class")
    End Sub
End Class
