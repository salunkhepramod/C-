using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml ;
using System.IO;

namespace myxmlgrid
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.HyperLink Hyperlink2;
		protected System.Web.UI.WebControls.DataGrid MyDataGrid;
		protected System.Web.UI.WebControls.CheckBox CheckBox1;
		ArrayList a1 = new ArrayList() ;
		ICollection CreateDataSource() 
		{
			DataTable dt = new DataTable();
			DataRow dr;
				
			dt.Columns.Add(new DataColumn("Qno", typeof(string)));
			dt.Columns.Add(new DataColumn("Subject", typeof(string)));
			dt.Columns.Add(new DataColumn("Question By", typeof(string)));
			dt.Columns.Add(new DataColumn("DateTimeValue", typeof(DateTime)));
			dt.Columns.Add(new DataColumn("total Replies", typeof(Int32)));
			dt.Columns.Add(new DataColumn("mailid", typeof(string)));
			dt.Columns.Add(new DataColumn("backcount", typeof(int)));

			string path = MapPath("csharp") ;
			DirectoryInfo d = new DirectoryInfo(path) ;
			FileInfo[] f = d.GetFiles() ;
			Session["count"] = f.Length ;
			int i = 1 ;
			for ( int ii = f.Length  ; ii>= 1 ; ii-- )
			{
				dr = dt.NewRow() ;
				dr[0] = i++ ;
				XmlDocument doc = new XmlDocument() ;
				doc.Load(path+ "\\csharp" + ii + ".xml" );
				XmlNodeList n = doc.GetElementsByTagName("subject");
				string sub = n.Item(0).InnerText ;
				if ( sub.Length > 40 )
				{
					sub = sub.Substring( 0,40 ) ;
					sub += "..." ;
				}
				dr[1] = sub ;

				n = doc.GetElementsByTagName("sender");

				XmlNodeList n1 = n.Item(0).ChildNodes ;

				dr[2] = n1.Item(0).InnerText ;
				dr[3] = n1.Item(1).InnerText ;
				dr[5] = n1.Item(2).InnerText ;
				dr[6] = ii ;
				n = doc.GetElementsByTagName("reply");
				dr[4] = n.Count ;
				dt.Rows.Add(dr);
			}

			DataView dv = new DataView(dt);
			return dv;
		}

		public WebForm1()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (CheckBox1.Checked) 
			{
				MyDataGrid.PagerStyle.Mode=PagerMode.NumericPages;
			}
			else 
			{
				MyDataGrid.PagerStyle.Mode=PagerMode.NextPrev;
			}

			MyDataGrid.DataSource = CreateDataSource();
			BindGrid() ;
		}
		void BindGrid()
		{
			MyDataGrid.DataBind();
		}

		private void Page_Init(object sender, EventArgs e)
		{
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.MyDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.MyDataGrid_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void MyDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			MyDataGrid.CurrentPageIndex = e.NewPageIndex;
			BindGrid();
		}
	}
}
